#!/usr/bin/env runhaskell
-- Filter for pandoc to insert landscape mode in Word-documents (.docx) 
{-# LANGUAGE OverloadedStrings #-}
import Text.Pandoc.JSON
import Data.Text (Text) 

beginLandscapeXml :: Text
beginLandscapeXml = "<w:p><w:pPr><w:sectPr><w:pgSz w:w='12240' w:h='15840'/></w:sectPr></w:pPr></w:p>"
endLandscapeXml :: Text
endLandscapeXml = "<w:p><w:pPr><w:sectPr><w:pgSz w:w='15840' w:h='12240' w:orient='landscape'/></w:sectPr></w:pPr></w:p>"

beginLandscapeBlock :: Block
beginLandscapeBlock = RawBlock (Format "openxml") beginLandscapeXml

endLandscapeBlock :: Block
endLandscapeBlock = RawBlock (Format "openxml") endLandscapeXml

insertLandscape :: Block -> Block 
insertLandscape (RawBlock (Format "html") "<!-- begin-landscape -->") = beginLandscapeBlock
insertLandscape (RawBlock (Format "html") "<!-- end-landscape -->") = endLandscapeBlock
insertLandscape blk = blk

main = toJSONFilter insertLandscape
