
Shiny.addCustomMessageHandler('activateNav', function(nav_label) {
	enable_tab(nav_label);
});

Shiny.addCustomMessageHandler('deactivateNav', function(nav_label) {
	disable_tab(nav_label);
});

disable_tab = function(nav_label) {
	x = $('#tabs a:contains("' + nav_label + '")');
	x.parent().addClass('disabled');
	x.attr('data-toggle', '');
};

enable_tab = function(nav_label) {
	x = $('#tabs a:contains("' + nav_label + '")');
	x.parent().removeClass('disabled');
	x.attr('data-toggle', 'tab');
};
