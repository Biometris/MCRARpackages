# Project: opex_git
#
# ui file - Data Entry
#
# Author: mvarewyck
###############################################################################



navbarMenu(title = "Data Entry",
    
    ## ----------- ##
    ## 1. Product  ##
    ## ----------- ##
    
    tabPanel(title = "Product", 
        
        navigationModuleUI(id = "product", title = "Product"),
        
        sidebarLayout(
            sidebarPanel(        
                fileInput(inputId = "entry_upload", 
                    label = "Load Saved Product (.zip)",
                    accept = ".zip"),
                helpText("Please refresh page before analyzing new product"),
                uiOutput("entry_errorLoad"),
                tags$h4("New Product"),
                uiOutput("entry_product")
            
            ), 
            
            mainPanel(
                
                tags$h3("Summary"),
                uiOutput("entry_showDownload"),
                
                tags$h4("Product"),
                uiOutput("entry_summaryProduct"),
                
                tags$h4("Active Substances"),
                entryTableModuleUI(id = "summarySubstance"),
                
                tags$h4("Application Scenarios"),
                entryTableModuleUI(id = "summaryCrop"),
                
                tags$h4("Intended Use"),
                entryTableModuleUI(id = "summaryAbsorption")
#                                            DTOutput("entry_summaryAbsorption")
            
            
            )
        )
    
    ),
    
    ## ------------ ##
    ## 2. Substance ##
    ## ------------ ##
    
    tabPanel(title = "Active Substances",
        
        navigationModuleUI(id = "substance", title = "Active Substances"),
        
        wellPanel(
            uiOutput("entry_substanceInput"),
            uiOutput("entry_substanceWarning")
        ),
        
        entryTableModuleUI(id = c("substance", "nested"))
    
    ),
    
    
    ## -------- ##
    ## 3. Crops ##
    ## -------- ##
    
    tabPanel(title = "Application Scenarios", 
        
        navigationModuleUI(id = "crop", title = "Application Scenarios"),
        
        wellPanel(
            uiOutput("entry_cropsInput"),
            uiOutput("entry_applicationInput"),
            uiOutput("entry_cropWarning")                                    
        ),
        
        entryTableModuleUI(id = c("crop", "nested"))
    
    ),
    
    
    ## ------------- ##
    ## 4. Absorption ##
    ## ------------- ##
    
    tabPanel(title = "Intended Use",
        
        navigationModuleUI(id = "absorption", title = "Intended Use"),
        
        actionButton("entry_refresh", label = "Refresh",
            icon = icon("sync")),
        
        tags$div(style = "inline-block",
            "To enter manually dermal absorption value(s) you can deselect 'Experimental Data?' (see Info page)"
        ),
        conditionalPanel(condition = "input.entry_formulation == 'G'",
            tags$div(style = "inline-block",
                paste0(getLabels("apDermal"), " is not applicable for ", getLabels("G"), ".")
            )
        ),
        uiOutput("entry_absorptionWarning"),
        
        tags$div(style = "margin-top:20px; margin-bottom:50px",
            rHandsontableOutput("entry_absorptionInput")
        )
    
    )

)