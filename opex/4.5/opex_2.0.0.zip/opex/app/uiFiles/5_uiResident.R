# Resident UI
# 
# Author: mvarewyck
###############################################################################


tabPanel(title = "Resident", {
			
	   fluidPage(

				
     h2("Description"),

					
					p(tags$b("Residents"), "are persons who live, work or attend school or any other institution adjacent to an area that is 
									or has been treated with a PPP; whose presence is quite incidental and unrelated to work involving PPPs 
									but whose position might lead them to be exposed; who take no action to avoid or control exposure; and who might be in 
									the location for up to 24 hours per day (short term exposure).  "),
					
					
          
					wellPanel(
              
              uiOutput(outputId = "resident_crop"),
              uiOutput(outputId = "resident_season"),
              DT::DTOutput("resident_entry"),
						  
          ),
       
     
					
					
					
					h2("Output"),
          uiOutput("resident_generalUI")
			
			
			)
			
		})
