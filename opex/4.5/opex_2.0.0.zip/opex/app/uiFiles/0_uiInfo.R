# Info page for the OPEX webtool
# 
# Author: mvarewyck
###############################################################################



tabPanel(title = "Info", {
      
      tagList(
          
#            tags$div(class = "watermark container",
#                  
#            ),
          
          tags$div(class = "container", style = "text-align:justify", 
              
              h1(id = "welcome", "Welcome to OPEX"),
              
              p("This tool is developed to provide estimates of the non-dietary exposure (for operators, workers, residents and bystanders) related to the use of plant protection products, therefore allowing a conclusion on the non-dietary risk assessment for these products.",
                  "It has been developed based on the following EFSA Guidance documents:",
                  
                  tags$ul(
                      tags$li("EFSA (European Food Safety Authority), Buist H, Craig P, Dewhurst I, Hougaard Bennekou S, Kneuer C, Machera K, Pieper C, Court Marques D, Guillot G, Ruffo F and Chiusolo A, 2017.",
                          "Guidance on dermal absorption. EFSA Journal 2017;15(6):4873, 60 pp.",
                          a(href = "https://efsa.onlinelibrary.wiley.com/doi/full/10.2903/j.efsa.2017.4873",
                              target="_blank", "https://doi.org/10.2903/j.efsa.2017.4873"),
                      ),
                      tags$li("EFSA (European Food Safety Authority), Charistou A, Coja T, Craig P, Hamey P, Martin S, Sanvido O, Chiusolo A, Colas M and Istace F, 2022. Guidance on the assessment of exposure of operators, workers, residents and bystanders in risk assessment of plant protection products. EFSA Journal 2022;20(1):7032, 134 pp.",
                          a(href="https://efsa.onlinelibrary.wiley.com/doi/epdf/10.2903/j.efsa.2022.7032", 
                              target="_blank", "https://doi.org/10.2903/j.efsa.2022.7032"))
                  ),
                  
                  "In the", actionLink(inputId = "info_dataEntry", label = "Data Entry"), 
                  "tab, users can enter or upload data on the", tags$b("Product, Active Substances, Application Scenarios"), 
                  "and", tags$b("Intended Use(s)"), "according to the GAP table of the product.",
                  
                  "On the", actionLink(inputId = "info_summary", label = "Summary"),
                  "page an overview is given on the safe use(s) concluded based on the calculations for each of these intended uses.",
                  "Detailed overviews of all estimated risks for the",
                  actionLink(inputId = "info_operator", label = "Operator"), "and", actionLink(inputId = "info_worker", label = "Worker"), 
                  "are provided along with a list of relevant personal protective equipment. Estimated risks (spray drift, vapour, surface deposits, entry into treated crops) are also given for ", actionLink(inputId = "info_resident", label = "Residents"),
                  "and", actionLink(inputId = "info_bystander", label = "Bystanders.")
              
              ),
              
              
              tags$h2("Data Entry"),
              
              tags$h3("Product"),
              
              tags$p("At the", actionLink(inputId = "info_dataEntry2", label = "Data Entry"),
                  "page, the user has two options to enter data:",
                  tags$ul(
                      tags$li("Enter a new product"),
                      tags$li("Upload a previously saved zip file containing already entered data.", tags$em("Note: the files contained in the zip file only serve to store the entered data.")), 
                  ),
                  "In both cases, you can enter/update data within the application as illustrated below.",
                  "When starting the calculations for a new product, using the browser refresh button  is recommended to erase all previous results."
              ),
              warningStyle(
                  tags$p("After", tags$b("10 minutes of inactivity"), "the app will stop working as expected.",
                      "Therefore,", 
                      "it is", tags$b("highly recommended"), "to download the zip file with all data for later use,",
                      "after entering all data for a product.",
                      "This can be done by pressing the save button which appears in the summary part of the product tab.",
                      "This zip file can easily be uploaded again on the Data Entry page.")),
              
              tags$p(
                  "The example product is called Lego which is a soluble concentrate with Product Category 'other'.",
                  "By pushing the button below, the example data will be loaded and you are redirected to the Data Entry page."
              ),
              
              #                    downloadButton(outputId = "info_exampleData", "Example Product"),
              actionButton(inputId = "info_example", label = "Example Product", 
                  icon = icon("play-circle")),
              
              # screenshot product
              screenshotStyle(file = "product.png"),
              
              tags$h3("Active Substances"),
              
              tags$p("After entering the product details, the Active Substances menu can be selected within Data Entry.",
                  "The user can also navigate between data entry pages using the buttons at the top-right corner of the page.",
                  "The next page will only be accessible when all necessary information at the current page has been entered."),
              
              tags$p("The name of the", tags$em("example") ,"active substance below is legolin 1.",
                  "The following values are entered:",
                  tags$ul(
                      tags$li("Concentration of Active Substance in the Product: 300 g a.s./l"),
                      tags$li("AOEL: 0.05 mg/kg bw/day"),
                      tags$li("AAOEL: 0.1 mg/kg bw"),
                      tags$li("Vapour pressure at 25\u2103: 1e-5 Pa"),
                      tags$li("Dermal Absorption from Experimental Data: 10% for 3 g a.s./l and 15% for 1 g a.s./l"),
                      tags$li("Oral Absorption: 100% (default that can be changed manually)"),
                      tags$li("Inhalation Absorption: 100% (default that can be changed manually)"),
                      tags$li("Molecular weight of the active substance and Experimental vapour concentration are optional, these values are used for an alternative 
                              calculation of the air concentration.")
                  )
              ),
              
              tags$p(
                  "The concentration of the active substance in the product is automatically entered in the first row of the dermal absorption table.", 
                  "When experimental data are available, the user can enter the dermal absorption values for the corresponding tested concentration(s).",
                  "These data will be used in estimating the dermal absorption for the Intended Use(s) (see below).",
                  "If no experimental data for the concentrate are available, default dermal absorption values can be entered manually in this first row.",
                  "If no experimental data for the dilution(s) are available, the appropriate dermal absorption value(s) have only to be reported in the sheet 'Intended Use'."
              ),
              
              # screenshot AS
              screenshotStyle(file = "substance.png"),
              
              
              tags$p(
                  tags$em(
                      "Note: The decimal separator used in the application is as configured on your computer.",
                      "1/2 is entered as 0.5 (or 0,5 depending on your system's decimal separator)."
                  ),
              ),
              tags$p(
                  tags$em(
                      "Note: Scientific notation can be entered with the letter e (e.g. 1e-4, 2e-3, 15e7)."
                  )
              ),
              
              tags$p("By pushing the '+Add' button, this active substance is added to the table and the cells are reset automatically.",
                  "This allows to enter as many active substances as needed for the product under consideration. In the example below, two substances were added, namely 'legolin 1' and 'legolin 2'."),
              
              # screenshot AS2
              screenshotStyle(file = "substance2.png"),
              tags$p(
                  "If the '+Add' button has a red colour, as shown in the image below, valuable information has not yet been provided.",
                  "Hovering over the '+Add' button will show which inputs are still missing. In the example, the AOEL needs to be specified.",
                  "Note that this also applies for adding application scenarios (Described in the next section)."
              ),
              screenshotStyle(file = "substance3.png"),
              
              tags$h3("Application Scenarios"),
              
              tags$p("The Application Scenarios menu is intended to provide details on the crops where the product will be applied to.",
                  "Field crops is the crop for the example product.",
                  "The following data have been introduced:",
                  tags$ul(
                      tags$li("Indoor/Outdoor: Outdoor"),
                      tags$li("Re-entry activity: Inspection, irrigation"),
                      tags$li("A maximum application rate of the product of 1 l/ha"),
                      tags$li("A single application of the product"),
                      tags$li("Normal type of cultivation (automatically selected for the crop under consideration)"),
                      tags$li("Minimal 100 l of water per hectare"),
                      tags$li("Maximal 300 l of water per hectare"),
                      tags$li("Buffer strip: 2-3 m"),
                      tags$li("Drift reduction: 0 %")
                  ),
                  "For the type of cultivation, the options “dense” and/or “normal” can both be included and will appear automatically if applicable to the crop under consideration.",
                  "The selected choices for the method of application will be automatically updated according to the selected crop type.",
                  "The realistic application methods are automatically included in the list.",
                  "If an application option is not considered relevant for the specific case (justification to be provided in the assessment report, outside of the calculator),",
                  "this application method can be removed manually from the list."),
              
              # screenshot crops
              screenshotStyle(file = "crops.png"),
              
              
              tags$p(
                  "By pushing the '+Add' button, this crop is added to the table.",
                  "You can similarly add information on other crops to which the product will be applied"),
              screenshotStyle(file = "crops2.png"),
              
              tags$h3("Intended Use"),
              
              tags$p("The displayed table is based on the information entered in the previous pages.", 
                  "The total amount of active substance applied per ha is calculated by multiplying the concentration of the active substance in the product with the application rate of the product.",
                  "The concentration of the active substance in the dilution is calculated as the total amount of applied substance per hectare divided by the maximum water volume per hectare (see Crops).",
                  "To avoid mistakes in the calculations, it is necessary to enter the application rate expressed on the basis of the product (and not as amount of active substance per hectare)."
              ),
              
              tags$p("Two options are available for specifying the dermal absorption:"),
              
              tags$b("Approach 1: Using experimental data"),
              tags$p("The concentration of the active substance in the dilution according to the intended uses (i.e. 'Concentration in the dilution')",
                  "is compared with the tested concentrations in the dermal absorption study (as entered for the Active Substance).", 
                  tags$ul(
                      tags$li("If the calculated dilution (e.g. 4 g/l) is within the range of two tested concentrations (i.e. 3 and 5 g/l), then the dermal absorption value from the lower bound (i.e. 15% for 3 g/l for the example) is automatically entered."),
                      tags$li("If the calculated dilution (e.g. 10 g/l) is higher than the tested concentrations (i.e. 5 g/l), then the dermal absorption value for the largest tested concentration (i.e. 5% for 5 g/l) is automatically entered."),
                      tags$li("If the calculated dilution (e.g. 0.3 g/l) is smaller than the lowest tested concentration (i.e. 0.6 g/l), then the dermal absorption value is automatically corrected by pro rata calculation (EFSA Guidance on Dermal Absorption, 2017).", 
                          "The dermal absorption of the smallest tested concentration is multiplied by the ratio of the smallest tested concentration divided by the calculated dilution (i.e. 20% multiplied by 0.6/0.3, or thus 40%).", 
                          "In any case, the dermal absorption value will be cut off at 70%.")
                  )
              ),
              tags$b("Approach 2: Absence of experimental data"), 
              tags$p("In case no experimental data is available, the user can de-select the tick box 'experimental data' and then either enter one dermal absorption value for all dilutions or the default dermal absorption values for the dilution according to EFSA Guidance on Dermal Absorption (2017).", 
                  "Please note that when using this option, justification should be provided in the assessment report."),
              
#                    "For instance, consider we have the following experimental data:",
              screenshotStyle(file = "intendedUse.png"),
              tags$p("The table also gives the option to refine the DFR and the DT50 for a certain scenario. This can be done by selecting the thick box in either worker, resident or",
                  "bystander. It will make the corresponding boxes editable for the person of interest."),
              
              screenshotStyle(file = "intentedUse2.png"),
#                    "The value for the concentration of the dilution turns out to be 3.57g a.s./l. Thus, 3g a.s./l is the highest smaller concentration and the suggested dermal absorption is 50%.",
              tags$p("Every time when an entry in the calculator is changed/adapted, the button “refresh” in the “Intended Uses” page has to be clicked, in order to accept the change and display it."),
              tags$h3("Product"),
              
              tags$p("After all entries are finalised, they can be reviewed and downloaded/saved for later use at the Product page.",
                  "Using the navigation buttons this page can, at any time, be accessed via the", icon("home"), "icon."),
              
              # screenshot product2
              screenshotStyle(file = "product2.png"),
              
              tags$h2("Summary"),
              
              tags$p("After entering all data, the exposure estimates for the product are displayed in the summary table.", 
                  "The least cumbersome protection is reported for which the total estimated exposure (both mixing/loading and application) is still below the (A)AOEL for all substances and relevant application equipments.", 
                  "In the example below, for short term systemic exposure, wearing workwear results in safe use during mixing & loading and application of Lego."),
              
              tags$p("All results from the WEB application can be downloaded by first pushing the 'Generate Report' button. When the report is done generating, ",
                  "the 'Download Report' button will become available and can be pressed next in order to start the actual download."),
              
              # screenshot summary
              screenshotStyle(file = "summary.png"),
              
              tags$h2("Operator"),
              
              tags$p("In this menu, an overview is given on the estimated short term and acute systemic exposure when using no protection or different combinations of protection (displayed as percentage of the (A)AOEL).",
                  "Under description, the user can find a list of possible scenarios for the operator (See the image below) and select a specific scenario to see a table with more detailed results. It is possible to order the rows by a certain column by clicking on the column name.",
                  "The first table under output shows the results for no protection and the least cumbersome protection, while the second table shows the results for all combinations of protection ",
                  "as implemented in the calculator (please note that the proposed tiered list is limited to plausible instead of all possible combinations, with the aim of being realistic and in agreement with agricultural practice).", 
                  "The user has also the possibility to check out the combined exposure of the substances in the product."),
              
              tags$p("At the first tier, combined exposure is calculated as the sum of the component exposures without regard to the mode of action or mechanism/target of toxicity.", 
                  "Initially, the individual Hazard Quotients (HQ) are calculated for all active substances in the PPP by dividing the individual exposure levels by the respective systemic AOEL.", 
                  "This is equivalent to the predicted exposure as % of systemic AOEL converted to decimal. The Hazard Index (HI) is the sum of the individual HQs."),
              # screenshot operator
              screenshotStyle(file = "operator.png"),
              screenshotStyle(file = "operator2.png"),
              screenshotStyle(file = "operator3.png"),
              
              tags$h2("Worker"),
              tags$p("In worker one can also (as in operator) select a specific scenario (row) to investigate", "the results. "),
              tags$p(
                  tags$em(
                      "Note: The Safe re-entry Interval (days) is rounded to the nearest integer equal to or above the calculated number."
                  )
              ),
              screenshotStyle(file = "worker.png"),
              tags$p("Scrolling down the page, the user can find the results for worker split in two tabs: 
                      'Per Substance' and 'Combined exposure'. In 'Per Substance' results are shown for four 
                      different kinds of level of protection for every substance."),
              
              screenshotStyle(file = "worker2.png"),
              
              # screen shot of worker all substances
              
              tags$p("In “Combined exposure”, the results are presented as Hazard Index (as for the operators)."),
              
              # screen shot of worker summary
              screenshotStyle(file = "worker3.png"),
              
              tags$p("On the summary page, the results are color-coded in the same way as for operators."),
              
              tags$h2("Resident/bystander"),
              
              tags$p("Resident and bystander are very similar to worker as they contain the same functionality.
                      In contrast to worker, a distinction is made between adults and children in the results.",
                  "In “Combined exposure”, the results are presented as Hazard Index (as for the operators)."),
              
              tags$p("On the summary page, the results are colour-coded as can be seen in the example below."),
              
              tags$b("Legend"),
              tags$p(drawBullet(color = myColors$green), "Safe use"),
              tags$p(drawBullet(color = myColors$yellow), "Safe use with drift reduction and/or increased buffer strip"),
              tags$p(drawBullet(color = myColors$red), "No safe use"),
              
              # screen shot of resident/bystander 
              screenshotStyle(file = "resident.png"),
              
              h1("Technical Documentation"),
              
              h2("News"),
              
              h3("opex 0.3.19"),
              tags$p("EFSA publication date: 18/01/2022"),
              tags$ul(
                  tags$li("First public version")
              ),
              h3("opex 0.3.20"),
              tags$p("EFSA publication date: Not published"),
              tags$ul(
                  tags$li("Fixed an issue with the outdoor use of Low vegetables with the activity Inspection and irrigation (All), now the correct worker hours are selected (8 instead of 2)"),
                  tags$li("Updated the definition for d_ByExpDur"),
                  tags$li("Fixed an issue with the coloring of the combined exposure on the summary page."),
                  tags$li("Corrected the intercept for the body part in the APP HCHH model (0 -> 4.19)."),
              ),
              h3("opex 0.3.21"),
              tags$p("EFSA publication date: Not published"),
              tags$ul(
                  tags$li("The cut-off value for the dermal absorption (dilution) is now 70% instead of 75%."),
                  tags$li("Fixed an issue with the coloring of the combined exposure tables for operator in both the summary tab and the operator tab."),
                  tags$li("Update guidance reference to the latest version (2022)."),
                  tags$li("Adjust rounding to 2 decimal points for DFR values in the intended uses table (the rounded value is also used in the calculations)."),
                  tags$li("Adjust rounding to 2 decimal points for MAF values (the rounded value is used in the calculations)."),
                  tags$li("The uses are now ordered, also in the report."),
                  tags$li("Fixed an issue where the report titles were showing the wrong scenario for operators in the report."),
                  tags$li("The combined re-entry interval calculation for workers in the summary page is updated to the correct calculation.")
              ),
              h3("opex 0.3.22"),
              tags$p("EFSA publication date: 25/04/2022"),
              tags$ul(
                  tags$li("Amenity grassland is now calculated using TTR instead of DFR for workers when the activity is Turf harvesting, cutting and handling."),
                  tags$li("The entry into treated crops for Agricultural grassland is now calculated in the same way as the other scenarios for resident and bystander (used to be like Amenity grassland)."),
                  tags$li("Entry into treated crops now shows values in case of Non arable land for residents and bystanders")
              ),
              h3("opex 0.3.23"),
              tags$ul(
                  tags$li("The numbering of the (sub)titles in the report is fixed."),
                  tags$li("The parameter 'Buffer strip' has been added in the Assessed Uses table of the report.")
              ),
              h3("opex 0.3.24"),
              tags$ul(
                  tags$li("Resident/bystander spray drift: maximum dermal absorption is adjusted to dermal absorption (dilution)")
              ),
              h3("opex 1.0.0"),
              tags$p("EFSA publication date: 16/12/2022"),
              tags$ul(
                  tags$li("Fix numbering when there are more than 10 uses."),
                  tags$li("A new column has been added to the intended uses table (use) to harmonise the numbering throughout the tool.")
                  
              ),
              h3("opex 2.0.0"),
              tags$p("EFSA publication date: TBD"),
              tags$ul(
                  tags$li("The cut-off value for dermal absorption (dilution) is 70%.")
              ),
              h2("Session info"),
              verbatimTextOutput(outputId = "sessionInfo"),
              
              h2("Icons Legend"),
              
              DTOutput("info_icons"),
              
              h2("Abbreviations"),
              
              "Note the following abbreviations",
              
              tags$ul(
                  tags$li("PPP: plant protection product"),
                  tags$li("PPE: personal protective equipment"),
                  tags$li("AOEL: acceptable operator exposure level"),
                  tags$li("AAOEL: acute acceptable operator exposure level"),
                  tags$li("a.s.: active substance"),
                  tags$li("bw: body weight"),
                  tags$li("DFR0: initial dislodgeable foliar residue"),
                  tags$li("DT50: dissipation time, within which the initial concentration is reduced to 50%"), 
                  tags$li("d0: when the applied product has dried")
              ),
              
              
              h2("Background Data"),
              
              p("Data sources used in the application can be consulted here"),
              selectInput(inputId = "summary_show", label = "Show",
                  choices = c(
                      "Default Values" = "default",
                      "Protection Correction Factors" = "protectionFactors", 
#                                    "Crops" = "crops",
                      "Default Application Equipment" = "equipment",
                      "Personal Protective Equipment" = "ppe",
                      "AOEM - outdoor models" = "aoem",
                      "Greenhouse - indoor models" = "indoor",
                      "Dermal transfer coefficients for worker" = "crops",
                      "Granules - indoor & outdoor models" = "granules"
                  )),
              
              uiOutput("info_table")
          
          
          )
      )
      
    })