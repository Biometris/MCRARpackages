# bystander UI
# 
# Author: mvarewyck
###############################################################################


tabPanel(title = "Bystander", {
			
			fluidPage(

					
     h2("Description"),
					
					p(tags$b("Bystanders"), "are persons  who  could  be  located  within  or  directly  adjacent  to  the  area  where PPP application or 
									treatment is in process or has recently been completed; whose presence is quite incidental and unrelated to work involving PPPs, 
									but whose position might lead them to be exposed during a short period of time (acute exposure); and who take no action to avoid or control exposure. "),
					
					
					
					wellPanel(
						  
              uiOutput("bystander_crop"),
              uiOutput(outputId = "bystander_season"),
              DT::DTOutput("bystander_entry"),
					    
					    
           ),
        
					h2("Output"),
          uiOutput("bystander_generalUI")
          
			
			
			)

		})
