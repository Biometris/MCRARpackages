# Project: opex_git
#
# ui file - Results for operator
# 
# Author: mvarewyck
###############################################################################




tabPanel(title = "Operator", {
			
			fluidPage(
					
					h2("Description"),
					
					p(tags$b("Operators"), "are persons who are involved in activities relating to the application of a plant protection product (PPP);
									such activities include mixing/loading the product into the application machinery, operation of
									the application machinery, repair of the application machinery whilst it contains the PPP and
									emptying/cleaning the machinery/containers after use. Operators may be either professionals
									(e.g. farmers or contract applicators engaged in commercial crop production) or amateur users
									(e.g. home garden users; it is noted that this tool does not include an assessment of this
									scenario)."),
					
					wellPanel(
							uiOutput("op_crop"),
              #uiOutput("op_substance"),
        			DT::DTOutput("op_entry"),
							uiOutput("op_warning")
					),	
					
					
					## ------------- ##
					## 1. Single PPE ##
					## ------------- ##
					
					h2("Output"),
     
					h3("Single Scenario"),
					
					tags$p("Estimated short term and acute exposure when using no protection and least cumbersome safe protection."),
					
					tags$div(style = "margin-bottom:50px", 
							DT::DTOutput("op_risksSingle")
					),
					
					
					## ---------- ##
					## 2. All PPE ##
					## ---------- ##
          h3("All Combinations of PPE"),
          radioButtons(inputId = "op_percentile",
              label = "Exposure",
              choices = c("Short term (75th percentile)" = "75", 
                  "Acute (95th percentile)" = "95"),
              inline = TRUE),
          
          tags$p("The estimated short term and acute exposure when wearing increasing level of protection is displayed as percentage of the (A)AOEL.",
              "Results are given for all active substances and all application scenarios."),
          
          uiOutput("op_legend"),
          
          uiOutput("op_warningExposure"),
					
          uiOutput(outputId = "op_tabs"),
			
			)
			
			
		})
