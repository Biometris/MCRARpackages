# Worker server
# 
# Author: mvarewyck
###############################################################################


## -------- ##
## Scenario ##
## -------- ##

## Select crop
output$worker_crop <- renderUI({
      
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      
      
      choices <- unique(results$cropData$id)
      names(choices) <- paste0(results$cropData$use[match(choices, results$cropData$id)], ": ", 
          results$cropData$crop[match(choices, results$cropData$id)])
      
      radioButtons(inputId = "worker_crop", label = "Crop", choices = choices,
          inline = TRUE)
      
    })


# All possible scenarios defined by crop
results$worker_scenarioData <- reactive({
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "worker",
          crops = allData$crops,
          dataDefault = allData$default
      )
      
    })

## Summary table of entered values for calculations
output$worker_entry <- DT::renderDT({
      
      req(input$worker_crop)
      
      data <- results$worker_scenarioData()[[input$worker_crop]]
      
      
      displayScenario(scenarios = data, 
          person = "worker")
      
    })

## -- ##
## UI ##
## -- ##

output$worker_uiOutput <- renderUI({
      req(input$worker_crop)
      req(input$entry_formulation)
      if (input$entry_formulation == "G" && 
          results$worker_scenarioData()[[input$worker_crop]]$indoor[1] == "Outdoor" && 
          results$worker_scenarioData()[[input$worker_crop]]$crop[1] != "Amenity grassland" && 
          results$worker_scenarioData()[[input$worker_crop]]$activity[1] != "Turf harvesting, cutting and handling") {
        warningStyle("No results available for Granules, fine granules!")
      } else if (is.na(results$worker_scenarioData()[[input$worker_crop]]$activity[1]) |
          results$worker_scenarioData()[[input$worker_crop]]$activity[1] == "NA") {
        warningStyle("No results available, no re-entry activity available for worker!")
      } else {
        tagList(
            h2("Output at d0"),
            
            h3("Single Scenario"),
            helpText(textOutput(outputId = "single_scenario_info")),
            
            tags$div(style = "margin-bottom:50px", 
                tableOutput("worker_risksSingle")
            ),
            
            h3("All Substances"),
            
            tabsetPanel(id = "worker_tabs",
                
                tabPanel("Per Substance",
                    uiOutput(outputId = "worker_risks"),
                
                ),
                tabPanel("Combined exposure",
                    
                    tableOutput(outputId = "worker_sumTables")
                
                )
            
            )
            
            )
      }
      
    })

## ------------ ##
## Calculations ##
## ------------ ##

## Tables for all substances
results$worker_tables <- reactive({
      req(input$worker_crop)
      data <- results$worker_scenarioData()[[input$worker_crop]]
  
      workerOutputTables(data, allData)
    }) 


## --------------- ##
## Single scenario ##
## --------------- ##

output$single_scenario_info <- renderText({
      
      "Possibility to select a different scenario (row) from the table above."
    })

output$worker_risksSingle <- renderTable({
      
      validate(need(input$worker_entry_rows_selected,
              "Please select a row from the table above"))
      tables <- results$worker_tables()
     
      
      roundFinal(tables[[input$worker_entry_rows_selected]])
      
    })

## ------------- ##
## Per Substance ##
## ------------- ##



output$worker_risks <- renderUI({
      
      req(input$worker_crop)
      
      lapply(seq_along(results$worker_tables()), function(noSubstance) {
            tagList(
                tags$h4(paste(results$worker_scenarioData()[[input$worker_crop]][noSubstance, c("substance")], collapse = " & ")),
                renderTable(roundFinal(results$worker_tables()[[noSubstance]]))
            )
            
          })
      
    })





## ----------------- ##
## Combined exposure ##
## ----------------- ##


## Sum over all substances and max(hours)


output$worker_sumTables <- renderTable({
      req(input$worker_crop)
      
      result <- outputSumTables(results$worker_tables(), 
          scenarioData = results$worker_scenarioData()[[input$worker_crop]],
          allData = allData)
      
      colnames(result)[6] <- "Hazard index at day 0"
      
      # calculate the safe re-entry interval
      intervals <- combinedSafeReEntryInterval(params = results$worker_scenarioData()[[input$worker_crop]], 
                                               tables = results$worker_tables(), allData)
      
      # Only replace safe re-entry interval if not NA
      idx <- which(!is.na(result[, 7]))
      result[idx, 7] <- intervals[idx]
                                            
      result
      
    })




