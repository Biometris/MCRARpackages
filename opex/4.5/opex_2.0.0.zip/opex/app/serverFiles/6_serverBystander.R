# bystander server
# 
# Author: mvarewyck
###############################################################################

## Select crop
output$bystander_crop <- renderUI({
      
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      
      
      choices <- unique(results$cropData$id)
      names(choices) <- paste0(results$cropData$use[match(choices, results$cropData$id)], ": ", 
          results$cropData$crop[match(choices, results$cropData$id)])
      
      radioButtons(inputId = "bystander_crop", label = "Crop", choices = choices,
          inline = TRUE)
      
    })

# Select season
output$bystander_season <- renderUI({
      req(input$bystander_crop)
      if(is.null(results$bystander_scenarioData()[[input$bystander_crop]]$season))
        req(NULL)
      else {
        
        choices <- unique(results$bystander_scenarioData()[[input$bystander_crop]]$season)
        
        
        radioButtons(inputId = "bystander_season", label = "Season", choices = choices,
            inline = TRUE)
      }
    })


## scenarios
results$bystander_scenarioData <- reactive({
      
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "bystander",
          crops = allData$crops,
          dataDefault = allData$default
      )
      
    })

# input data per crop and per season
observe({
      req(input$bystander_crop)
      req(input$bystander_season)
      results$bystander_perCrop <- results$bystander_scenarioData()[[input$bystander_crop]]
      results$bystander_perSeason <- results$bystander_perCrop[results$bystander_perCrop$season == input$bystander_season, ]
    })


# Summary of entered values for calculations
output$bystander_entry <- DT::renderDT({
      req(results$bystander_perSeason)
      
      data <- results$bystander_perSeason
      
      displayScenario(scenarios = data, 
          person = "bystander")
      
      
    })

output$bystander_generalUI <- renderUI({
      req(input$bystander_crop)
      req(input$bystander_season)
      if(nrow(results$bystander_perSeason) > 0) {
        if(results$bystander_perSeason[1, "formulation"] == 'G' & results$bystander_perSeason[1, "indoor"] == "Indoor") {
          warningStyle("No results available for Granules, fine granules indoor!")
        } else {
          tagList(
              h3("Single Scenario"),
              helpText(textOutput(outputId = "bystander_single_scenario_info")),
              tags$div(style = "margin-bottom:50px", 
                  uiOutput("bystander_risksSingle")
              ),
              uiOutput(outputId = "bystander_tabs")
          )
        }
      }
    })

output$bystander_single_scenario_info <- renderText({
      
      "Possibility to select a different scenario (row) from the table above."
    })

output$bystander_risksSingle <- renderUI({
      
      validate(need(input$bystander_entry_rows_selected,
              "Please select a row from the table above"))
      tables <- results$bystander_tables()
      
      table <- tables[[input$bystander_entry_rows_selected]]
      fluidRow(
          lapply(names(table), function(x)
                column(6, 
                    tags$h4(x),
                    renderTable(roundFinal(table[[x]]), rownames = TRUE)
                )
          )
      )
      
      
      
    })


# general ui layout (2 tabpages)
observe({
      
      output$bystander_tabs <- renderUI({
            tabsetPanel(
                tabPanel("Per Substance",
                    uiOutput(outputId = "bystander_risks")
                ),
                tabPanel("Combined exposure", 
                    helpText("The results are presented as exposure addition."),
                    uiOutput(outputId = "bystander_sumTables")
                )
            )
            
          })
      
    })

##-------------##
## default DFR ##
##-------------##



## Tables for all substances
results$bystander_tables <- reactive({
      req(results$bystander_perSeason)
      if(nrow(results$bystander_perSeason) > 0)
        bystanderOutputTables(results$bystander_perSeason)
    }) 



output$bystander_risks <- renderUI({
      
      lapply(seq_along(results$bystander_tables()), function(noSubstance)	{	
            
            textOutput("bystander_substanceTitles")
            allRisks <- results$bystander_tables()[[noSubstance]]
            
            tagList(
                tags$h3(results$bystander_perSeason[noSubstance, "substance"]),
                fluidRow(
                    lapply(names(allRisks), function(x)
                          column(6, 
                              tags$h4(x),
                              renderTable(roundFinal(allRisks[[x]]), rownames = TRUE)
                          )
                    )
                
                )
            )
          })
    })





##-------------------##
## combined exposure ##
##-------------------##


# default dfr
output$bystander_sumTables <- renderUI({
      
      tables <- outputSumTables2(results$bystander_tables())
      
      rownames(tables$Children)[3] <- "Hazard index"
      rownames(tables$Adults)[3] <- "Hazard index"
      
      fluidRow(
          lapply(names(tables), function(x)
                column(6, 
                    tags$h4(x),
                    renderTable(tables[[x]], rownames = TRUE)
                )
          )
      )
      
    })

