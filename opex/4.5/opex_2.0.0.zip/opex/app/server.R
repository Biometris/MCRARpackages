serverFunction <- function(input, output, session){
  
  output$debug <- renderUI({
        
        if (doDebug)
          tags$p(
              actionLink("debug_console", "Connect with R Console", icon = icon("exchange-alt")),
          #verbatimTextOutput("debug_print") this gives a null in the webapp
          )
        
      })
  
  # For debugging
  observe({
        
        if (is.null(input$debug_console))
          return(NULL)
        
        if (input$debug_console > 0) {
          
          options(browserNLdisabled = TRUE)
          saved_console <- ".RDuetConsole"
          if (file.exists(saved_console)) {load(saved_console)}
          isolate(browser())
          save(file = saved_console, list = ls(environment()))
          
        }
        
      })
  
  output$debug_print <- renderPrint({
        
        input$worker_input_cell_edit
        
      })
  
  
  
  output$version <- renderText(paste("Version", packageVersion("opex")))
  
  
  # Report
  output$report <- downloadHandler(
      filename = "report.pdf",
      content = function(file) {
        
        rmarkdown::render(file.path("www", 'report.Rmd'), output_file = file)
        
      })
  
  
  efsaHeader <- efsaHeaderServer(id = "header")
  
  results <- reactiveValues(
      
      # 1_entry #
      # ------- #
      
      loadedFiles = NULL,
      
      ## Product
      productDefault = productDefault,
      productData = NULL,
      
      ## Substances
      # Default values for input fields
      substanceDefault = substanceDefault,
      # Data frame with all
      substanceData = NULL,
      
      ## Crops
      # Default values for input fields
      cropDefault = cropDefault,
      # Data frame with all
      cropData = NULL,
      
      ## Method of application
      methodDefault = methodDefault,
      
      ## Absorption for Intended Use
      absorptionData = data.frame(
          substance = NA,
          crop = NA
      ),
      
      # 3_operator #
      # ---------- # 
      
      # Table with selected ppe
      op_ppe = NULL,
      
      
      # 4_worker #
      # -------- # 
      
      worker_input = defaultWorker,
      
      # 5_resident #
      # ---------- # 
      
      resident_input = defaultResident,
      
      # 6_bystander #
      # ----------- # 
      
      bystander_input = defaultResident
  
  )
  
  
  # Load code for all tabpages
  serverFiles <- list.files(path = system.file("app/serverFiles", package = "opex"))
  for (iFile in serverFiles)
    source(file.path("serverFiles", iFile), local = TRUE)
  
  
  # Show tabpanels
  output$tabPanels <- renderUI({
        
        uiFiles <- list.files(path = system.file("app/uiFiles", package = "opex"))
        
        allTabs <- lapply(uiFiles, function(iFile) 
              source(file.path("uiFiles", iFile), local = TRUE)$value
        )
        
        do.call(navbarPage, c(title = "", id = "tabs", allTabs))
        
      })
  
  
  
  
  ### -------------------------------------------------------------------------
  ### Tab Access Control
  ### -------------------------------------------------------------------------
  
  enableTab <- function(tab) {
    session$sendCustomMessage("activateNav", tab)
    
    # cascade
    if (tab == "Summary") {
      
      enableTab("Operator")
      enableTab("Worker")
      enableTab("Resident")
      enableTab("Bystander")
      
    } 
    
  }
  
  disableTab <- function(tab) {
    session$sendCustomMessage("deactivateNav", tab)
    
    # cascade
    if (tab == "Active Substances") disableTab("Application Scenarios")
    if (tab == "Application Scenarios") disableTab("Intended Use")
    if (tab == "Intended Use") disableTab("Summary")
    if (tab == "Summary") {
      
      disableTab("Operator")
      disableTab("Worker")
      disableTab("Resident")
      disableTab("Bystander")
      
    }
    
  }
  
  # Upon start - disable all tabs
  disableTab("Active Substances")
  
  
}



