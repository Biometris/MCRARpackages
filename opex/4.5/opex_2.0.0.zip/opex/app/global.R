## (1) Load packages for the app

library(opex)

#library(plotly)				# interactive plots
library(rhandsontable)		# for interactive tables
#library(shinyjs)			# for toggling buttons
library(DT)
library(efsaStyle)
# Not loaded, only limited functions used
# rmarkdown

## (2) Debugging


onStop(function() {
      if (file.exists(".RDuetConsole"))
        file.remove(".RDuetConsole")
    })

if (!exists("doDebug"))
  doDebug <- FALSE

if (!exists("doLoad"))
  doLoad <- FALSE

if (!doDebug)
  options(warn = -1)



## (3) General settings for the app

options(stringsAsFactors = FALSE)

`%then%` <- function(x, y) {
  
  if (is.null(x) || isTRUE(is.na(x)))
    y
  else
    x
  
}


# OA colors
myColors <- list(
    "red" = "#f5b7b1",
    "green" = "#abebc6",
    "blue" = "#9bd4e9",
    "yellow" = "#f4d03f",
    "gray" = "#cacfd2"
) 

# style for screenshots
screenshotStyle <- function(file) {
  
  div(class = "figure", align = "center", style = "margin-top:10px; margin-bottom:10px;",
      img(src = file, width = "100%", 
          style = paste("border-radius: 10px; border:2px solid", myColors$gray)))
  
}

# style for warnings
warningStyle <- function(...) {
  
  textItems <- list(...)
  
  tags$div(style = "color:red; font-style:italic", lapply(textItems, tags$p))
  
}

# draw bullet in specific color
drawBullet <- function(color) {
  
  div(style = paste0("background-color: ", color, 
          "; display: inline-block; vertical-align:top; width: 20px; height: 20px; border-radius: 10px"))
  
}




## Copy OA style file
styleFile <- file.path(system.file("app/www", package = "opex"), "oaStyle.css")
if (!file.exists(styleFile))
  file.copy(from = file.path(system.file("css", package = "oaStyle"), "reports.css"),
      to = styleFile)



# TODO Copy package code
zipFile <- paste0("opex_", packageVersion("opex"), ".zip")
if (doDebug && !file.exists(file.path("www", zipFile))) {
  
  oldDir <- getwd()
  setwd("~/git/opex2/")
  wwwFolder <- "opex/inst/app/www"
  
  allFiles <- untar(paste0("opex_", packageVersion("opex"), ".tar.gz"), list = TRUE)
  zip(zipfile = zipFile, files = allFiles)
  file.copy(from = zipFile,
      to = file.path(wwwFolder, zipFile),
      overwrite = TRUE)
  
  # Remove old zip files
  allZip <- list.files(wwwFolder, pattern = ".zip")
  unlink(file.path(wwwFolder, allZip[!allZip %in% zipFile]))
  
  setwd(oldDir)
  
}





## (4) Data for the app


# Load default data from EFSA excel file
allData <- loadData()

# Default values for product
productDefault <- data.frame(
    name = "",
    formulation = "",
    wps = FALSE,
    category = ""
)

# Default values for Active Substances
substanceDefault <- data.frame(
    substance = "",
    
    concentration = NA,
    aoel = NA,
    aaoel = NA,
    pressure = 0.001,
    
    # Absorption of active substance
    mlDermal = NA,
    oral = 100,
    inhalation = 100,
    #dermalWorker = NA,
    
    molecularWeight = NA,
    vapourConcentrationExp = NA,
    
    dfr0 = 3,
    dt50 = 30,
    
    
    worker = FALSE,
    dfrSpecWorker = 3,
    dt50FoliarWorker = 30,
    dt50AirWorker = 30,
    dt50SoilWorker = 30,
    
    res = FALSE,
    dfrSpecRes = 3,
    dt50Res = 30,
    
    bystander = FALSE,
    dfrSpecBys = 3,
    dt50Bys = 30

)

# Default values for Crop
cropDefault <- data.frame(
    crop = "",
    
    maxRate = NA,
    unit = "kg/ha",
    maxNo = 1,
    interval = 7,
    density = "normal; dense",
    minVolume = NA,
    maxVolume = NA,
    indoor = "Outdoor",
    activity = NA,
    activityTSF = NA,
    bufferStrip = "2-3",
    driftReduction = 0,
    applicationMethod = "Downward spraying"


)

# Default values for Method of application
methodDefault <- data.frame(
    
    applicationEquipment_normal = "TM; HHTank; HHKnap; HHTrolley",
    applicationEquipment_dense = "TM; HHTank; HHKnap; HHTrolley"

)

# Default values for worker
defaultWorker <- data.frame(
    # Crop type
    crop = allData$crops$`Crop type`[7],
    # Application method
    applicationMethod = c("Downward spraying", "Upward spraying")[1],
    # Application Rate [kg a.s./ha]
    maxRate = 3,
    
    # half-life (50%) dissipation time [days]
    dt50 = 30,
    # Number of applications
    maxNo = 1,
    # Interval between multiple applications [days]
    interval = 365,
    # Indoor/outdoor
    indoor = c("Indoor", "Outdoor")[2],
    
    # Dermal absorption [%]
    ## in concentrate (undiluted product)
    dermalConcentrate = 100,
    ## in dilution (in-use dilution)
    dermalDilution = 100,
    
    # Dislodgeable foliar residue [microg/cm2]
    ## default or specific
    dfr_spec = 3,
    ## worker exposure study
    dfr = NA
)

# Default values for resident
defaultResident <- data.frame(
    # Crop type
    crop = "Citrus fruit",
    
    # Application method
    applicationMethod = c("Downward spraying", "Upward spraying")[1],
    # Formulation type
    formulation = c("granules", "WP", "WG", "liquid")[4],
    # Buffer strip [m]
    bufferStrip = c("2-3", "5", "10")[3],
    # Application Rate [kg a.s./ha]
    maxRate = 0.9,
    # Season
    ## choices only available for 'Fruit crops', otherwise only 'not relevant'
    # NOTE: Independent of season choice for Operator!
    season = c("not relevant", "early season", "late season")[1],
    # Min volume of water [l/ha]
    minVolume = 300,
    
    # Dermal absorption [%]
    dermal = 50,
    # Inhalation absorption [%]
    inhalation = 75,
    # Oral absorption [%]
    oral = 85,
    
    # Dislodgeable foliar residue [microg/cm2]
    ## measured
    dfr = NA,
    ## Initial DFR [microg a.s./cm2]
    dfr_spec = 3,
    # Re-entry restriction period [days]
    reentry = NA,
    
    # half-life (50%) dissipation time [days]
    dt50 = 30,
    # Number of applications
    maxNo = 1,
    # Interval between multiple applications [days]
    interval = 365,
    
#        # Vapour pressure - not used Sabine
#        pressure = c("low", "moderate")[1],
    # Vapour concentration
    vapourConcentration = getDefault(name = c("d_AirConNonVol", "d_AirConVol"))[1],
    
    # Vehicle mounted drift reduction factor [%] (0% is no reduction)
    driftReduction = 0,
    
    stringsAsFactors = FALSE
)


# PPE for multiple scenarios (outdoor, indoor, indoorDenseLow, indoorDenseHigh)
protectionTable <- allData$ppe


# Full names for labels
fullLabels <- fullNames(type = "labels", rev = TRUE)

