## ---- echo = FALSE------------------------------------------------------------
library(vembedr)
embed_vimeo("505287449") %>%
  use_align("center")

## ---- echo = FALSE------------------------------------------------------------
library(vembedr)
embed_vimeo("505286442") %>%
  use_align("center")

