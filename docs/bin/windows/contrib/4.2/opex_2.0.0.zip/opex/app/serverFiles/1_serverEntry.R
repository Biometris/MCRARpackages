# Project: opex_git
#
# server file - Data Entry
#
# Author: mvarewyck
###############################################################################


# Refresh table for Intended Use
refresh <- 0
newFile <- FALSE



## ----------- ##
## 0. Download ##
## ----------- ##


# Valid information for all aspects
results$entry_valid <- reactive({
      
      if (is.null(results$productData))
        FALSE else
        nrow(results$productData) > 0 & !any(results$productData == "") & 
            !is.null(results$substanceData) &
            !is.null(results$cropData) &
            nrow(results$entry_absorptionData()) > 0 &
            !any(is.na(results$entry_absorptionData()$apDermal))
      
    })


# Control tabpages
observe({
      
      req(!is.null(results$entry_valid()))
      if (results$entry_valid())
        enableTab("Summary") else
        disableTab("Summary")
      
    })




## Download data
output$entry_download <- downloadHandler(
    filename = function() {
      tmpName <- if (input$entry_name == "")
            "opex" else
            input$entry_name
      
      paste0(tmpName, "_", format(Sys.time(), "%Y%m%d_%Hh%M"), "_opex", packageVersion("opex"), ".zip")
    },
    content = function(file) {
      
      oldDir <- getwd()
      setwd(tempdir())
      on.exit(setwd(oldDir))
      
      # Create files
      dataFiles <- c(
          "product.csv",
          "substance.csv",
          "crop.csv",
          "absorption.csv"
      )
      
      tryCatch({
            # Product
            write.csv(results$productData, file = dataFiles[1], 
                row.names = FALSE)
            # Active Substances
            write.csv(results$substanceData, file = dataFiles[2],
                row.names = FALSE)
            # Crops 
            write.csv(results$cropData, file = dataFiles[3],
                row.names = FALSE)
            # Absorption Data
            write.csv(results$entry_absorptionData(), file = dataFiles[4],
                row.names = FALSE)
            
          }, error = function(e) 
            showNotification(sprintf("Data files could not be generated: %s", e$message),
                type = "error")
      )
      
      zip(zipfile = file, files = dataFiles)
      
    },
    contentType = "application/zip")




# Download button
output$entry_showDownload <- renderUI({
      
      # Need all info before user can save
      validate(need(results$entry_valid(),
              "Please complete data to download product data."
          ),
          need(!any(is.na(results$entry_absorptionData()$apDermal)),
              "Please go to 'Intended Use' page to refresh data."),
          need(all(results$substanceData$id %in% results$entry_absorptionData()$idSubstance) &
                  all(results$cropData$id %in% results$entry_absorptionData()$idCrop),
              "Please refresh the Intended Use table to match with updated Active Substances and Crops."
          ))
      
      tagList(
          downloadButton(outputId = "entry_download", label = "Save Product")
      )
      
    })

# Summary of product
output$entry_summaryProduct <- renderUI({
      
      validate(need(!any(results$productData == ""), "Please enter product information"))
      
      tagList(
          tags$p(tags$b(fullLabels["name"], ":"), results$productData$name),
          tags$p(tags$b(fullLabels["formulation"], ":"), fullLabels[results$productData$formulation]),
          conditionalPanel(condition = "['WP', 'SC', 'WG'].includes(input.entry_formulation)",
              tags$p(tags$b(fullLabels["wps"], ":"), ifelse(input$entry_wps, "Yes", "No"))
          ),
          
          tags$p(tags$b(fullLabels["category"], ":"), results$productData$category)
      )
      
    })


observe({
      
      # Substance
      callModule(
          module = entryTableModuleServer, 
          id = "summarySubstance",
          data = reactive(results$substanceData),
          addButtons = NULL)
      
      # Crop
      callModule(
          module = entryTableModuleServer, 
          id = "summaryCrop",
          data = reactive({
                results$cropData
              }),
          addButtons = NULL)
      
      # Intended Use
      callModule(
          module = entryTableModuleServer, 
          id = "summaryAbsorption",
          # Extended GAP table
          data = reactive({
                
                validate(need(nrow(results$entry_absorptionData()) > 0,
                        "No data added"))
                
                # intended use data
                gapData <- results$entry_absorptionData()
                
                # other data sources
                cropData <- results$cropData[!duplicated(results$cropData$id), c("id", "minVolume", "maxVolume", "maxRate", "unit")]
                substanceData <- results$substanceData[!duplicated(results$substanceData$id), c("id", "concentration")]
                allData <- merge(merge(gapData, cropData, 
                        by.x = "idCrop", by.y = "id", all.x = TRUE),
                    substanceData,
                    by.x = "idSubstance", by.y = "id", all.x = TRUE)
                
                # min concentration in dilution
                # Concentration in the product
                allData$tmpConcentration <- calculateTA(
                    concentration = allData$concentration, 
                    maxRate = allData$maxRate, 
                    unit = allData$unit, 
                    maxVolume = allData$minVolume, 
                    areaTreated = 1)
                # Concentration in the dilution
                allData$dilutionConcentrationMin <- allData$dilutionConcentration
                allData$dilutionConcentrationMax <- allData$tmpConcentration / allData$minVolume
                
                allData[, c("idSubstance", "idCrop", "use", "substance", "crop",
                        "productConcentration",
                        paste0(c("min", "max"), "Volume"),
                        paste0("dilutionConcentration", c("Min", "Max")),
                        "defaultDermal", "apDermal", "dfr0", "dt50", 
                        "dfrSpecWorker", "dt50FoliarWorker", "dt50AirWorker", "dt50SoilWorker", "dfrSpecRes", "dt50Res", "dfrSpecBys", "dt50Bys")]
                
              }),
          addButtons = NULL)
      
    })



## Upload previous data
results$entry_errorLoad <- eventReactive(input$entry_upload, {
      
      tryCatch({
            oldDir <- getwd()
            setwd(tempdir())
            on.exit(setwd(oldDir))
            
            newFiles <- lapply(list(
                    product = "product.csv",
                    substance = "substance.csv",
                    crop = "crop.csv",
                    absorption = "absorption.csv"
                ), function(x) file.path(tempdir(), x))
            
            sapply(newFiles, unlink)
            
            unzip(input$entry_upload$datapath)
            
            
            ## Read data
            results$loadedFiles <- newFiles
            
            results$productDefault <- read.csv(file = results$loadedFiles$product, stringsAsFactors = FALSE)
            newFile <<- TRUE
            
            if (!grepl(packageVersion("opex"), input$entry_upload$name))
              warningStyle("Data loaded from previous opex version, this may cause errors!")  
            else
              helpText("Data loaded correctly")
            
          }, error = function(err) warningStyle("Data could not be loaded"))
      
    })

# Print error when loading data
output$entry_errorLoad <- renderUI(results$entry_errorLoad())



## Upload example data
observeEvent(input$info_example, {
      
      # Copy files
      newFiles <- list.files(path = system.file("extdata", package = "opex"),
          pattern = "example_")
      
      file.copy(
          from = file.path(system.file("extdata", package = "opex"), newFiles), 
          to = file.path(tempdir(), newFiles), 
          overwrite = TRUE)
      
      ## Read data
      results$loadedFiles <- as.list(file.path(tempdir(), newFiles))
      names(results$loadedFiles) <- gsub("example_|.csv", "", newFiles)
      
      results$productDefault <- read.csv(file = results$loadedFiles$product, stringsAsFactors = FALSE)
      newFile <<- TRUE
      
      print("Example data loaded correctly")
      
    })




# Debugging - load default data
observe({
      
      if (doLoad) {
        
        newFiles <- lapply(c(TRUE, FALSE), function(x)
              list.files(path = system.file("extdata", package = "opex"),
                  pattern = "test_", full.names = x))
        newFiles <- as.list(newFiles[[1]]) 
        names(newFiles) <- gsub("test_|.csv", "", newFiles[[2]])
        
        ## Read data
        results$loadedFiles <- newFiles
        
        results$productDefault <- read.csv(file = results$loadedFiles$product, stringsAsFactors = FALSE)
        newFile <<- TRUE
        # TODO test whether this works correctly for absorption, used to be global variable newFile
        # TODO refresh button no longer works
      }
      
    })



## ---------- ##
## 1. Product ##
## ---------- ##

# Control tabpages
observe({
      
      # Update when this changes
      results$entry_valid()
      
      if (is.null(results$productData))
        disable <- TRUE else
        disable <- nrow(results$productData) == 0 | any(results$productData == "")
      
      if (disable)
        disableTab("Active Substances") else
        enableTab("Active Substances")
      
    })

results$productPage <- callModule(
    module = navigationModuleServer, 
    id = "product",
    current = "Product")

# Home - left - right buttons
observe({
      results$productPage$time
      updateNavbarPage(session = session, inputId = "tabs", 
          selected = results$productPage$newPage)
    })



output$entry_product <- renderUI({
      
      tagList(
          textInput(inputId = "entry_name", label = getLabels("name"),
              value = results$productDefault$name),
          selectInput(inputId = "entry_formulation", label = getLabels("formulation"),
              choices = list(
                  "Please select" = "",
                  "Solubles" = list(
                      "Wettable powder, soluble powder" = "WP", 
                      "Wettable granules, soluble granules" = "WG",
                      "Soluble concentrates, emulsifiable concentrate, etc." = "SC"
                  ),
                  "Non-Solubles" = list(
                      "Granules, fine granules" = "G"
                  )
              ), selected = results$productDefault$formulation),
          # water soluble bags
          conditionalPanel(condition = "['WP', 'WG', 'SC'].includes(input.entry_formulation)",
              checkboxInput(inputId = "entry_wps", label = "Water soluble bags", value = results$productDefault$wps)
          ),
          
          # Info for category
          tags$div(title = paste("When 'herbicide' is selected, the application method will always be downward spraying", 
                  "If 'other' is selected, the application method can be either downward or upward spraying depending on the crop selected."),
              tags$b(getLabels("category")),
              icon("info-circle")
          ),
          
          selectInput(inputId = "entry_category", label = NULL,
              choices = c(
                  "Please select" = "",
                  "Herbicide" = "herbicide",
                  "Other" = "other"
              ), selected = results$productDefault$category)
      
      )
      
    })

observe({ 
      
      results$productData <- data.frame(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category
      )
      
    })



## ------------ ##
## 2. Substance ##
## ------------ ##

# Control tabpages
observe({
      
      # Update when this changes
      results$entry_valid()
      
      if (is.null(results$substanceData))
        disableTab("Application Scenarios") else
        enableTab("Application Scenarios")
      
    })


results$substancePage <- callModule(
    module = navigationModuleServer, 
    id = "substance",
    current = "Active Substances")

# Home - left - right buttons
observe({
      results$substancePage$time
      updateNavbarPage(session = session, inputId = "tabs", 
          selected = results$substancePage$newPage)
    })



# Input fields
output$entry_substanceInput <- renderUI({
      
      # Update to default when added to table
      input[["substance-entry_add"]]
      
      
      tagList(
          
          textInput(inputId = "entry_substance", label = 
                  fullLabels["substance"],
              value = results$substanceDefault$substance[1]),
          
          fluidRow(
              column(3,
                  tags$div(title = paste("Concentration of the active substance in the product is expressed as technical material, i.e. the one used for testing and (A)AOEL derivation.",
                          "This value is automatically entered in the first row of the dermal absorption table below, only editable here"),
                      tags$b(fullLabels["concentration"]),
                      icon("info-circle")),
                  numericInput(inputId = "entry_concentration", 
                      label = NULL,
                      value = results$substanceDefault$concentration[1])
              ),
              column(3, tags$div(title = "Acceptable Operator Exposure Level", 
                      numericInput(inputId = "entry_aoel", 
                          label = fullLabels["aoel"], 
                          value = results$substanceDefault$aoel[1]))
              ),
              column(3, tags$div(title = "Acute Acceptable Operator Exposure Level",
                      numericInput(inputId = "entry_aaoel", 
                          label = fullLabels["aaoel"], 
                          value = results$substanceDefault$aaoel[1]))),
              column(3,
                  tags$div(title = paste("If no value is entered, no results will be shown for vapour in resident/bystander. \n",
                          "A value below 5e-3 will trigger a default air concentration of 1e-3.\n", 
                          "A value higher than 5e-3 will trigger a default air concentration of 15e-3. \n",
                          "The unit for air concentration is [mg/m\u00B3]."),
                      tags$b(fullLabels["pressure"]),
                      icon("info-circle")),
                  numericInput(inputId = "entry_pressure", 
                      label = NULL, 
                      value = results$substanceDefault$pressure[1])
#                                    selectInput(inputId = "entry_pressure", 
#                                            label = fullLabels["pressure"],
#                                            choices = fullNames(type = "pressure"),
#                                            selected = results$substanceDefault$pressure[1])
              # NOTE: used for residents/bystanders
              )
          ),
          
          # Absorption
          
          tags$h3("Absorption of the Active Substance"),
          
          fluidRow(
              column(6,
                  tags$div(title = paste("The concentration of the active substance in the product is automatically entered in the first row of the dermal absorption table.", 
                          "When experimental data are available, the user can enter the dermal absorption values for the corresponding tested concentration(s).",
                          "These data will be used in estimating the dermal absorption for the Intended Use(s).",
                          "If no experimental data for the concentrate are available, default dermal absorption values can be entered manually in this first row.",
                          "If no experimental data for the dilution(s) are available, the appropriate dermal absorption value(s) have only to be reported in the sheet 'Intended Use'."),
                      tags$b(fullLabels["dermal"],
                          "from experimental data or default value for concentrate"),
                      icon("info-circle")
                  ),
                  
                  rHandsontableOutput("entry_dermal"),
                  helpText("You can add rows by right-clicking in the table.")
              ), 
              column(2, 
                  numericInput(
                      inputId = "entry_oral",
                      label = fullLabels["oral"],
                      value = results$substanceDefault$oral[1])
              ),
              column(2, 
                  numericInput(
                      inputId = "entry_inhalation",
                      label = fullLabels["inhalation"],
                      value = results$substanceDefault$inhalation[1])
              ),
          # refinment for worker (probably later uses)
#              column(2,
#                  tags$div(title = paste("Optional"),
#                      tags$b(fullLabels["dermalWorker"]),
#                      icon("info-circle")),
#                  numericInput(
#                      inputId = "entry_dermalWorker",
#                      label = NULL,
#                      value = results$substanceDefault$dermalWorker[1]
#                  )
#              )
          ),
          
          tags$div(title = paste("Optional. Only if it triggers an air concentration below the default value, the default value will be replaced."),
              tags$em("Air concentration calculation"),
              icon("info-circle")),
          fluidRow(
              column(6, numericInput(inputId = "entry_molecularWeight", 
                      label = getLabels("molecularWeight"), value = results$substanceDefault$molecularWeight[1])),
              column(6, numericInput(inputId = "entry_vapourConcentrationExp", 
                      label = getLabels("vapourConcentrationExp"), value = results$substanceDefault$vapourConcentrationExp[1]))
          )
      
      
      
      
      )
      
    })



# Experimental data for dermal absorption
output$entry_dermal <- renderRHandsontable({
      
      defaultConcentrations <- results$substanceDefault$concentration
      if (length(defaultConcentrations) < 6)
        defaultConcentrations <- c(defaultConcentrations, rep(NA, 6 - length(defaultConcentrations)))
      defaultValues <- results$substanceDefault$mlDermal
      if (length(defaultValues) < 6)
        defaultValues <- c(defaultValues, rep(NA, 6 - length(defaultValues)))
      
      # Read-only value for dermal absorption - concentration
      defaultConcentrations[1] <- input$entry_concentration
      
      newCols <- fullLabels[c("testedConcentration", "dermal")]
      names(newCols) <- NULL
      
      rhandsontable(
              data = data.frame(
                  concentration = as.numeric(defaultConcentrations),
                  mlDermal = as.numeric(defaultValues)
              ),
              rowHeaders = c(
                  "Concentrate (product)", 
                  paste("Dilution", 1:5, "tested")
              ),
              rowHeaderWidth = 200,
              colHeaders = newCols,
              stretchH = "all",
              overflow = "visible"
          ) %>%
          hot_cell(row = 1, col = 1, readOnly = TRUE) %>%
          # To make sure enough digits are shown
          hot_cols(renderer = htmlwidgets::JS("safeHtmlRenderer"))
      
    })


# Values for new substance
results$entry_newSubstance <- reactive({
      
      newData <- substanceDefault
      newData[, c("mlDermal", "concentration")] <- NULL
      for (iName in names(newData)) {
        newData[, iName] <- input[[paste0("entry_", iName)]]
      }
      
      
      # Dermal absorption values - add table
      req(input$entry_dermal)
      dermalTable <- hot_to_r(input$entry_dermal)
      toInclude <- !is.na(dermalTable$mlDermal)
      newData <- cbindFill(newData, dermalTable[toInclude, ])
      
      if (!is.null(results$substanceDefault$id))
        newData$id <- results$substanceDefault$id[1:nrow(newData)]
      
      newData
      
    })

# Updated reactive values are returned
tmpResultsSubstance <- callModule(
    module = entryModuleServer, 
    id = "substance",
    # Read old entries from file 
    # Substance2: contains example with two substances
    file = reactive(results$loadedFiles$substance),
    # New data
    new = results$entry_newSubstance,
    # Default values
    default = substanceDefault)


# Copy reactive values -> not working directly!
# https://stackoverflow.com/a/48883055/5840900
observe({ 
      
      results$substanceDefault <- tmpResultsSubstance$default
      results$substanceData <- tmpResultsSubstance$data
      
      
    })


# Print warnings for entered substance
output$entry_substanceWarning <- renderUI({
      
      if (!is.null(input$entry_dermal)) {
        
        # experimental data dilution unique names
        tmpNames <- hot_to_r(input$entry_dermal)$concentration
        allNames <- tmpNames[!is.na(tmpNames) & tmpNames != ""]
        
        missingVariables <- colnames(results$entry_newSubstance())[
            apply(results$entry_newSubstance(), 2, function(x) all(is.na(x) | x == ""))]
        # rename mlDermal
        missingVariables[missingVariables == "mlDermal"] <- "dermal"
        
        # optional entry parameters
        notRequired <- c("molecularWeight", "vapourConcentrationExp", "aaoel")
        missingVariables <- missingVariables[!missingVariables %in% notRequired]
        
        title <- paste(
            if (input$entry_substance %in% results$substanceData$substance)
              "Please provide a unique name for the Active Substance\n",
            if (length(unique(allNames)) != length(allNames))
              "Please provide a unique concentration in the Experimental data for dermal absorption\n",
            if (length(missingVariables) > 0)
              paste(
                  "Values are missing for:\n",
                  paste(
                      sapply(missingVariables, function(iName) 
                            paste(fullLabels[iName], 
                                if (iName %in% c("aoel", "aaoel")) 
                                  paste(": No results for", switch(iName, aoel = "Short term", aaoel = "Acute"), "exposure will be shown")
                            )
                      ), 
                      collapse = "\n")
              )
        )
      } else title <- NULL
      
      entryButtonModuleUI(id = "substance", title = title)
      
    })



## ------------------------ ##
## 3. Application Scenarios ##
## ------------------------ ##


# Control tabpages
observe({
      
      # Update when this changes
      results$entry_valid()
      
      if (is.null(results$cropData))
        disableTab("Intended Use") else
        enableTab("Intended Use")
      
    })

results$cropPage <- callModule(
    module = navigationModuleServer, 
    id = "crop",
    current = "Application Scenarios")

# Home - left - right buttons
observe({
      results$cropPage$time
      updateNavbarPage(session = session, inputId = "tabs", 
          selected = results$cropPage$newPage)
    })




output$entry_cropsInput <- renderUI({
      
      # Update to default when added to table
      input[["crop-entry_add"]]
      
      validate(need(input$entry_formulation, 
              "Please select formulation type in the Data Entry Product page."))
      
      if (!is.null(input$entry_formulation))
        unitChoices <- if (input$entry_formulation %in% c("WP", "WG", "G"))
              c("kg/ha", "%") else
              c("l/ha", "%")
      
      
      tagList(
          
          fluidRow(
              column(3, 
                  selectInput(inputId = "entry_crop", 
                      label = fullLabels["crop"],
                      choices = c("Please select" = "",
                          unique(allData$cropExamples$cropGroup)),
                      selected = results$cropDefault$crop
                  )),
              
              column(3, selectInput(inputId = "entry_indoor", 
                      label = fullLabels["indoor"],
                      choices = NULL, 
                      selected = NULL)),
              column(3,
                  uiOutput(outputId = "entry_activityUI")   
              ),
              column(3,
                  uiOutput(outputId = "entry_activityTSFUI")   
              )
          
          ),
          
          uiOutput("entry_cropInfo"),
          uiOutput("entry_workerTC"),
          
          # Amount
          tags$h3("Application Rate"),
          
          fluidRow(
              column(4, 
                  fluidRow(
                      column(9, numericInput(inputId = "entry_maxRate",
                              label = fullLabels["maxRate"],
                              value = results$cropDefault$maxRate)),
                      column(3, selectInput(inputId = "entry_unit", 
                              label = fullLabels["unit"],
                              choices = unitChoices,
                              selected = results$cropDefault$unit)) 
                  )
              ),
              column(4, numericInput(inputId = "entry_maxNo",
                      label = fullLabels["maxNo"],
                      value = results$cropDefault$maxNo)),	
              column(4, uiOutput("entry_intervalInput"))
          # NOTE: Used for worker
          ),
          
          fluidRow(
              
              column(4, uiOutput("entry_density")
              ),
              conditionalPanel(condition = "input.entry_formulation != 'G'",
                  column(4, numericInput(inputId = "entry_minVolume", 
                          label = fullLabels["minVolume"],
                          value = results$cropDefault$minVolume)
                  # NOTE: needed for resident/bystander only
                  ),
                  
                  column(4, numericInput(inputId = "entry_maxVolume", 
                          label = fullLabels["maxVolume"],
                          value = results$cropDefault$maxVolume)
                  )
              )
          ),
      
      ) 
      
    })



output$entry_workerTC <- renderUI({
      req(input$entry_crop)
      req(input$entry_activity)
      if (is.null(input$entry_activity)) {
        NULL
      } else {
        
        if (input$entry_indoor == "Indoor" & input$entry_formulation != "G") {
          correctRow <- allData$crops[allData$crops$'Crop type' == input$entry_crop & 
                  allData$crops$activity == input$entry_activity & allData$crops$activityTSF == input$entry_activityTSF, ]
          # only for harvesting is category important 
          if(length(correctRow$category) > 1) {
            correctRow <- correctRow[correctRow$category == input$entry_category, ]
          }
        } else {
          
          correctRow <- allData$crops[allData$crops$'Crop type' == input$entry_crop & 
                  allData$crops$activity == input$entry_activity, ]
          correctRow <- correctRow[1, ]
        }
        
        
        tagList(
            
            tags$p(tags$b("Dermal transfer coefficients for worker:")),
            
            fluidRow(
                
                column(2, 
                    renderText(paste0("Total potential exposure [cm\u00B2/h]: ",correctRow$dermalTcUCV))
                ),
                column(2, 
                    renderText(paste0("Arm, body and legs covered [cm\u00B2/h]: ", correctRow$dermalTcCV1))
                ),
                column(2, 
                    renderText(paste0("Hands, arm, body and legs covered [cm\u00B2/h]: ", correctRow$dermalTcCV2))
                ),
                column(2, 
                    renderText(paste0("Hands covered, no workwear [cm\u00B2/h]: ", correctRow$dermalTcCV3))
                ),
                if (input$entry_indoor == "Indoor" & input$entry_formulation != "G") {
                  column(2, 
                      renderText(paste0("TSF [mg a.s./h ha/kg a.s.]: ", correctRow$TSF))
                  )
                }
            )
        )
        
      }
      
      
    })

output$entry_activityUI <- renderUI({
     req(input$entry_indoor)
      
      
      if (input$entry_indoor == "Indoor") {
        activityChoices <- allData$crops$activity[allData$crops$'Crop type' == input$entry_crop & allData$crops$'indoor' == 1]
      } else {
        activityChoices <- allData$crops$activity[allData$crops$'Crop type' == input$entry_crop] 
      }
      
      selectInput(inputId = "entry_activity",
          label = getLabels("activity"),
          choices = activityChoices,
          selected = results$cropDefault$activity)
      
    })




output$entry_activityTSFUI <- renderUI({
      req(input$entry_crop)      
      req(input$entry_indoor)
      req(input$entry_activity)
      
      if (input$entry_indoor == "Indoor" & input$entry_formulation != "G") {
        activityChoices <- unique(allData$crops$activityTSF[allData$crops$'Crop type' == input$entry_crop & allData$crops$activity == input$entry_activity]) 
        
        
        selectInput(inputId = "entry_activityTSF",
            label = paste(getLabels("activity"), "TSF"),
            choices = activityChoices,
            selected = results$cropDefault$activityTSF)
      } else {
        NULL
      }
      
    })

observe({
      req(input$entry_crop)
      req(results$cropDefault)
      
      tmpChoices <- unique(allData$equipment$scenario[allData$equipment$cropGroup == input$entry_crop])
      choices <- c("Indoor", "Outdoor")[c("indoor" %in% tmpChoices, "outdoor" %in% tmpChoices)]
      
      # when indoor is the only choice, it is automatically selected (only the case for Strawberry (indoor))
      # outdoor is selected as default
      selected_indoor <- NULL
      defaultValue <- isolate(results$newIndoor)
      if (!is.null(defaultValue)) {
        selected_indoor <- defaultValue
        isolate(results$newIndoor <- NULL)
      } else {
        selected_indoor <- "Outdoor"
      }
      
      
      if(input$entry_crop == "Strawberry (indoor)") {
        selected_indoor <- "Indoor"
      }
      
      
      updateSelectInput(session, inputId = "entry_indoor", choices = choices, selected = selected_indoor)
      
    })

observe({
      req(results$methodDefault)
      req(input$entry_applicationMethod)
      req(input$entry_crop)
      if(input$entry_formulation == "G"){
        updateSelectInput(session, inputId = "entry_density", choices = "normal", selected = "normal")
        if(input$entry_indoor == "Indoor") {
          choices_normal <- "Manual-Hand held"
          choices_dense <- ""
          selected_normal <- "Manual-Hand held"
        } else {
          choices_normal <- c("Vehicle-mounted", "Manual-Hand held")
          choices_dense <- ""
          selected_normal <- c("Vehicle-mounted", "Manual-Hand held")
        }
        updateSelectInput(session, inputId = "entry_applicationEquipment_normal", 
            choices = choices_normal, 
            selected = selected_normal)
      } else {
        choicesNormalTmp <- c(strsplit(results$methodDefault$applicationEquipment_normal, split = ";")[[1]])
        choicesDenseTmp <- c(strsplit(results$methodDefault$applicationEquipment_dense, split = ";")[[1]])
        
        choicesNormalTmp <- names(fullNames(type = "applicationEquipment"))[match(choicesNormalTmp, fullNames(type = "applicationEquipment"))]
        choicesDenseTmp <- names(fullNames(type = "applicationEquipment"))[match(choicesDenseTmp, fullNames(type = "applicationEquipment"))]
        
        choices_normal <- choicesNormalTmp[!is.na(choicesNormalTmp)]
        choices_dense <- choicesDenseTmp[!is.na(choicesDenseTmp)]
        
        
        selected_dense <- ""
        defaultValue <- isolate(results$newEquipment_dense)
        if (!is.null(defaultValue)) {
          selected_dense <- trimws(strsplit(defaultValue, split = ";")[[1]])
          isolate(results$newEquipment_dense <- NULL)
        } else if (!is.null(results$methodDefault$applicationEquipment_normal)) {
          tmp_dense <- trimws(strsplit(results$methodDefault$applicationEquipment_dense, split = ";")[[1]])
          selected_dense <- names(fullNames(type = "applicationEquipment"))[match(tmp_dense, fullNames(type = "applicationEquipment"))]
        }
        if(input$entry_applicationMethod == "Manual") {
          updateSelectInput(session, inputId = "entry_applicationEquipment_normal", 
              choices = choices_normal, 
              selected = selected_normal)
        } else {
          selected_normal <- NULL
          defaultValue <- isolate(results$newEquipment_normal)
          if (!is.null(defaultValue)) {
            selected_normal <- trimws(strsplit(defaultValue, split = ";")[[1]])
            isolate(results$newEquipment_normal <- NULL)
          } else if (!is.null(results$methodDefault$applicationEquipment_normal)) {
            tmp_normal <- trimws(strsplit(results$methodDefault$applicationEquipment_normal, split = ";")[[1]])
            selected_normal <- names(fullNames(type = "applicationEquipment"))[match(tmp_normal, fullNames(type = "applicationEquipment"))]
          }
          
          updateSelectInput(session, inputId = "entry_applicationEquipment_normal", 
              choices = choices_normal, 
              selected = selected_normal)
        }
        updateSelectInput(session, inputId = "entry_applicationEquipment_dense", 
            choices = choices_dense, 
            selected = selected_dense)
      }
      
      
    })

observe({
      req(input$entry_indoor)
      
      if (input$entry_indoor == "Indoor") {
        activityChoices <- allData$crops$activity[allData$crops$'Crop type' == input$entry_crop & allData$crops$'indoor' == 1]
      } else {
        activityChoices <- allData$crops$activity[allData$crops$'Crop type' == input$entry_crop] 
      }
      
      updateSelectInput(session, inputId = "entry_activity", choices = activityChoices, selected = results$cropDefault$activity)
      
    })

observe({
      req(input$entry_activity)
      
      if (input$entry_indoor == "Indoor" & input$entry_formulation != "G") {
        activityChoices <- unique(allData$crops$activityTSF[allData$crops$'Crop type' == input$entry_crop & allData$crops$activity == input$entry_activity]) 
        
        
        updateSelectInput(session, inputId = "entry_activityTSF",
            choices = activityChoices,
            selected = results$cropDefault$activityTSF)
      } else {
        NULL
      }
      
    })


output$entry_cropInfo <- renderUI({
      
      req(input$entry_crop)
      
      subData <- allData$cropExamples[allData$cropExamples$cropGroup == input$entry_crop, ]
      if (input$entry_indoor == "Indoor")
        subData <- subData[subData$Indoor == 1, ] else
        subData <- subData[subData$Outdoor == 1, ]
      
      validate(need(nrow(subData) == 1, "No examples available"))
      
      tagList(
          tags$p(tags$b("Crop Type"), subData$cropType),
          tags$p(tags$b("Crop Examples"), subData$cropExamples)
      )
      
    })

observe({
      req(input$entry_crop)
      
      if(identical(results$methodDefault$applicationEquipment_dense, ""))
        choices = "normal"
      else
        choices = c("normal", "dense")
      
      selected <- NULL
      defaultValue <- isolate(results$newDensity)
      if (!is.null(defaultValue)) {
        selected <- c(trimws(strsplit(defaultValue, split = ";")[[1]])) 
        isolate(results$newDensity <- NULL)
      } else {
        selected <- c("normal", "dense")
      }
      if (input$entry_formulation == "G") {
        choices <- "normal"
        selected <- "normal"
      }
      
      updateSelectInput(session, inputId = "entry_density", choices = choices, 
          selected = selected)
      
    })


output$entry_density <- renderUI({
      
      selectInput(inputId = "entry_density", 
          label = fullLabels["density"],
          choices = NULL,
          selected = NULL,
          multiple = TRUE)
    })

# Method of application
output$entry_applicationInput <- renderUI({
      input[["crop-entry_add"]]
      
      tagList(
          conditionalPanel(condition = "input.entry_crop",
              # Method
              tags$h3("Method of Application"),
              
              fluidRow(
                  column(4, uiOutput("entry_applicationMethod")),
                  column(8, 
                      uiOutput("entry_applicationEquipment"),
                      uiOutput("entry_applicationWarning"))
              
              )
          ),
          fluidRow(
              column(6, 
                  selectInput(inputId = "entry_bufferStrip", 
                      label = getLabels("bufferStrip"), choices = c("2-3", "5", "10"), selected = results$cropDefault$bufferStrip)
              ),
              column(6,
                  selectInput(inputId = "entry_driftReduction", 
                      getLabels("driftReduction"), choices = c(0, 50), selected = results$cropDefault$driftReduction),
              )
          ),
          span(textOutput(outputId = "entry_warningUpward23m"), style = "color:red")
      
      
      
      )
      
    })

observe({
      req(input$entry_applicationMethod)
      req(input$entry_bufferStrip)
      if (grepl("Upward", input$entry_applicationMethod) & input$entry_bufferStrip == "2-3") {
        output$entry_warningUpward23m <- renderText({"No results available for spray drift using a buffer strip of 2-3m, please select a different buffer strip."})
      } else {
        output$entry_warningUpward23m <- NULL
      }
    })

# Select time interval for multiple applications
output$entry_intervalInput <- renderUI({
      
      req(input$entry_maxNo)
      
      if (input$entry_maxNo > 1)
        numericInput(inputId = "entry_interval",
            label = fullLabels["interval"],
            value = results$cropDefault$interval)
      
    })




# Determine default method of application based on input
observe({
      req(input$entry_crop)
      req(input$entry_applicationMethod)
      
      results$methodDefault <- defaultEquipment(
          defaultData = allData$equipment, 
          crop = req(input$entry_crop), 
          category = req(input$entry_category),
          indoor = req(input$entry_indoor) == "Indoor",
          applicationMethod = input$entry_applicationMethod
      )      
      
    })



observe({
      req(input$entry_crop)
      req(input$entry_category)
      req(input$entry_indoor)
      
      data <- allData$equipment
      data <- data[data$cropGroup == input$entry_crop & 
              data$productCategory == input$entry_category & 
              data$scenario == tolower(input$entry_indoor), ]
      
      results$applicationMethods <- unique(c("Upward spraying", "Downward spraying")[data$downward + 1]) 
    })



# Method of application
output$entry_applicationMethod <- renderUI({
      req(results$applicationMethods)
      
      if (input$entry_formulation == "G")
        choices <- c("Broadcast", "In furrow")
      else choices <- results$applicationMethods 
      
      if (input$entry_indoor == "Indoor" & input$entry_formulation == "G") {
        NULL
      } else {
        selectInput(inputId = "entry_applicationMethod", 
            label = fullLabels["applicationMethod"],
            choices = choices, 
            selected = results$cropDefault$applicationMethod)
      }
    })


# Select application equipment
output$entry_applicationEquipment <- renderUI({
      
      fluidRow(
          column(6, 
              conditionalPanel("input.entry_density !== null && input.entry_density.indexOf('normal') > -1",
                  selectInput(inputId = "entry_applicationEquipment_normal", 
                      label = fullLabels["applicationEquipment_normal"],
                      choices = NULL,
                      selected = NULL,
                      multiple = TRUE)
              )
          ),
          column(6,
              conditionalPanel("input.entry_density !== null && input.entry_density.indexOf('dense') > -1",
                  selectInput(inputId = "entry_applicationEquipment_dense", 
                      label = fullLabels["applicationEquipment_dense"],
                      choices = NULL,
                      selected = NULL,
                      multiple = TRUE)
              )
          )
      )
      
      
    })


output$entry_applicationWarning <- renderUI({
      
      relevantSelected <- c(input$entry_applicationEquipment_normal[("normal" %in% input$entry_density)],
          input$entry_applicationEquipment_dense["dense" %in% input$entry_density])
      
      if ("TM" %in% relevantSelected & input$entry_indoor == "Indoor")
        warningStyle("For indoor scenario, no results will be shown for 'Vehicle-mounted'")
      
    })

# New values for crop
results$entry_newCrop <- reactive({
      
      newData <- cbind(cropDefault, methodDefault)
      newData[, c("density", "applicationEquipment_normal", "applicationEquipment_dense")] <- NULL
      
      for (iName in names(newData))
        if (is.null(input[[paste0("entry_", iName)]]))
          newData[, iName] <- NA else
          newData[, iName] <- input[[paste0("entry_", iName)]]
      
      # determine the use
      number <- "Use 1"
      i <- 1
      while(number %in% results$cropData$use) {
        i <- i + 1
        number <- paste("Use", i)
      }
      Use <- number
      
      uses <- data.frame(use = rep(Use, times = length(input$entry_density)))
      
      newData <- cbindFill(uses, newData)
      
      # Application method not applicable for indoor scenarios granules
      if(input$entry_formulation == "G") {
        newData[newData$indoor == "Indoor", "applicationMethod"] <- NA
      }
      
      if(newData$indoor == "Outdoor" | input$entry_formulation == "G") {
        newData$activityTSF <- NA 
      }
      
      # Application Technique - add table
      techniqueTable <- data.frame(
          density = input$entry_density,
          applicationEquipment = sapply(input$entry_density, function(iDensity)
                paste(input[[paste0("entry_applicationEquipment_", iDensity)]], collapse = "; "))
      )
      
      # If no density selected
      if (nrow(techniqueTable) == 0)
        techniqueTable <- data.frame(
            density = NA, 
            applicationEquipment = NA
        )
      
      newData <- cbindFill(newData, techniqueTable)
      
      if (!is.null(results$cropDefault$id))
        newData$id <- results$cropDefault$id
      
      newData
      
    })



# Updated reactive values are returned
tmpResultsCrop <- callModule(
    module = entryModuleServer, 
    id = "crop",
    # Read old entries from file
    file = reactive(results$loadedFiles$crop),
    # New data
    new = results$entry_newCrop,
    # Default values
    default = cbind(cropDefault, methodDefault))




# Copy reactive values -> not working directly!
observe({ 
      req(tmpResultsCrop$data)
      
      # order by use
      myData <- tmpResultsCrop$data[order(tmpResultsCrop$data[["use"]]), ]
      orderBy <- as.numeric(unlist(stringr::str_split(myData[["use"]], pattern = " ")))
      orderBy <- orderBy[!is.na(orderBy)] 
      results$cropData <- myData[order(orderBy), ]
      
      if (is.null(tmpResultsCrop$default$interval))
        tmpResultsCrop$default$interval <- NA
      
      
      # Crops
      wideDefault <- tmpResultsCrop$default
      
      
      if (nrow(wideDefault[wideDefault$density == "normal", ]) != 0) {
        wideDefault$applicationEquipment_normal <- wideDefault[wideDefault$density == "normal", "applicationEquipment"]
        wideDefault$applicationEquipment_normal <- paste(wideDefault$applicationEquipment_normal, collapse = "; ")
      }
      
      
      if (nrow(wideDefault[wideDefault$density == "dense", ]) != 0) {
        wideDefault$applicationEquipment_dense <- wideDefault[wideDefault$density == "dense", "applicationEquipment"]
        wideDefault$applicationEquipment_dense <- paste(wideDefault$applicationEquipment_dense, collapse = "; ")
      }
      
      wideDefault$density <- paste(wideDefault$density, collapse = "; ")
      results$cropDefault <- wideDefault[1, , drop = FALSE]
      
      # Treat separately
      if (tmpResultsCrop$usedEdit) {
        results$newEquipment_normal <- results$cropDefault$applicationEquipment_normal
        results$newEquipment_dense <- results$cropDefault$applicationEquipment_dense
        results$newDensity <- results$cropDefault$density
        results$newIndoor <- results$cropDefault$indoor
      }
    })




# Print warnings for entered substance
output$entry_cropWarning <- renderUI({
      
      if (!is.null(input$entry_crop)) {
        
        missingVariables <- colnames(results$entry_newCrop()[1,])[
            apply(results$entry_newCrop()[1, ], 2, function(x) all(is.na(x) | x == ""))]
        
        if (input$entry_formulation == 'G') {
          notRequired <- c("minVolume", "maxVolume")
          missingVariables <- missingVariables[!missingVariables %in% notRequired]
        }
        
        if (input$entry_formulation == 'G' & input$entry_indoor == "Indoor") {
          notRequired <- c("applicationMethod")
          missingVariables <- missingVariables[!missingVariables %in% notRequired]
        }
        
        if(input$entry_formulation == "G" | input$entry_indoor == "Outdoor") {
          notRequired <- c("activityTSF")
          missingVariables <- missingVariables[!missingVariables %in% notRequired]
        }
        
        # Exception for interval
        if ("interval" %in% missingVariables && input$entry_maxNo <= 1)
          missingVariables <- missingVariables[-match("interval", missingVariables)]
        selectedCrops <- results$cropData$crop
        
        title <- paste(
            
            if (length(missingVariables) > 0)
              paste(
                  "Values are missing for:\n",
                  paste(
                      sapply(missingVariables, function(iName) 
                            fullLabels[iName]), 
                      collapse = "\n")
              )
        )
        
      } else title <- NULL
      
      
      entryButtonModuleUI(id = "crop", title = title)
      
    })



## --------------- ##
## 4. Intended Use ##
## --------------- ##


# Control tabpages
results$absorptionPage <- callModule(
    module = navigationModuleServer, 
    id = "absorption",
    current = "Intended Use")

# Home - left - right buttons
observe({
      results$absorptionPage$time
      updateNavbarPage(session = session, inputId = "tabs", 
          selected = results$absorptionPage$newPage)
    })



# Entered values for Intended Use
results$entry_absorptionData <- reactive({
      
      req(!is.null(input$entry_refresh))
      
      if (is.null(input$entry_absorptionInput)) {
        # 1st time or pushing Refresh button
        
        myData <- expand.grid(
            idSubstance = unique(results$substanceData$id),
            idCrop = unique(results$cropData$id),
            defaultDermal = TRUE,
            apDermal = as.numeric(NA),
            dfr0 = substanceDefault$dfr0,
            dt50 = substanceDefault$dt50,
            worker = substanceDefault$worker,
            dfrSpecWorker = as.numeric(substanceDefault$dfrSpecWorker),
            dt50FoliarWorker = substanceDefault$dt50FoliarWorker,
            dt50AirWorker = substanceDefault$dt50AirWorker,
            dt50SoilWorker = substanceDefault$dt50SoilWorker,
            res = substanceDefault$res,
            dfrSpecRes = as.numeric(substanceDefault$dfrSpecRes),
            dt50Res = substanceDefault$dt50Res,
            bys = substanceDefault$bys,
            dfrSpecBys = as.numeric(substanceDefault$dfrSpecBys),
            dt50Bys = substanceDefault$dt50Bys,
            
            
            stringsAsFactors = FALSE
        )
        
        # Match IDs with names
        indexSubstance <- match(myData$idSubstance, results$substanceData$id)
        myData$substance <- results$substanceData$substance[indexSubstance]
        indexCrop <- match(myData$idCrop, results$cropData$id)
        myData$crop <- results$cropData$crop[indexCrop]
        indexUse <- match(myData$idCrop, results$cropData$id)
        myData$use <- results$cropData$use[indexUse]
        
        # Concentration in the product (per ha)
        myData$productConcentration <- calculateTA(
            concentration = results$substanceData$concentration[indexSubstance], 
            maxRate = results$cropData$maxRate[indexCrop], 
            unit = results$cropData$unit[indexCrop], 
            maxVolume = results$cropData$maxVolume[indexCrop], 
            areaTreated = 1  # concentration per ha
        )
        # Concentration in the dilution
        myData$dilutionConcentration <- myData$productConcentration / results$cropData$maxVolume[indexCrop]
        
        
        
        
        
      } else if (refresh != input$entry_refresh)  {
        
        # Update table with user input 
        myCurrentData <- hot_to_r(input$entry_absorptionInput)
        
        myData <- expand.grid(
            idSubstance = unique(results$substanceData$id),
            idCrop = unique(results$cropData$id),
            defaultDermal = TRUE,
            apDermal = as.numeric(NA),
            dfr0 = substanceDefault$dfr0,
            dt50 = substanceDefault$dt50,
            worker = substanceDefault$worker,
            dfrSpecWorker = as.numeric(substanceDefault$dfrSpecWorker),
            dt50FoliarWorker = substanceDefault$dt50FoliarWorker,
            dt50AirWorker = substanceDefault$dt50AirWorker,
            dt50SoilWorker = substanceDefault$dt50SoilWorker,
            res = substanceDefault$res,
            dfrSpecRes = as.numeric(substanceDefault$dfrSpecRes),
            dt50Res = substanceDefault$dt50Res,
            bys = substanceDefault$bys,
            dfrSpecBys = as.numeric(substanceDefault$dfrSpecBys),
            dt50Bys = substanceDefault$dt50Bys,
            
            
            stringsAsFactors = FALSE
        )
        
        # Match IDs with names
        indexSubstance <- match(myData$idSubstance, results$substanceData$id)
        myData$substance <- results$substanceData$substance[indexSubstance]
        indexCrop <- match(myData$idCrop, results$cropData$id)
        myData$crop <- results$cropData$crop[indexCrop]
        indexUse <- match(myData$idCrop, results$cropData$id)
        myData$use <- results$cropData$use[indexUse]
        
        # Concentration in the product (per ha)
        myData$productConcentration <- calculateTA(
            concentration = results$substanceData$concentration[indexSubstance], 
            maxRate = results$cropData$maxRate[indexCrop], 
            unit = results$cropData$unit[indexCrop], 
            maxVolume = results$cropData$maxVolume[indexCrop], 
            areaTreated = 1  # concentration per ha
        )
        # Concentration in the dilution
        myData$dilutionConcentration <- myData$productConcentration / results$cropData$maxVolume[indexCrop]
        
        # Reorder columns
        newOrder <- c("use", "substance", "crop", 
            "productConcentration", "dilutionConcentration", "defaultDermal", 
            "apDermal", "dfr0", "dt50", "worker", "dfrSpecWorker", "dt50FoliarWorker", "dt50AirWorker", "dt50SoilWorker", 
            "res", "dfrSpecRes", "dt50Res",
            "bys", "dfrSpecBys", "dt50Bys", "idSubstance", "idCrop")
        myData <- myData[, newOrder[newOrder %in% colnames(myData)]]
        
        
        for (crop in unique(myCurrentData$idCrop)) {
          for (substance in unique(myCurrentData$idSubstance)) {
            if (crop %in% myData$idCrop & substance %in% myData$idSubstance) {
              myData[myData$idCrop == crop & myData$idSubstance == substance, c("worker", "dfrSpecWorker", "dt50FoliarWorker", "dt50AirWorker", "dt50SoilWorker",
                      "res", "dfrSpecRes", "dt50Res",
                      "bys", "dfrSpecBys", "dt50Bys")] <- myCurrentData[myCurrentData$idCrop == crop & 
                          myCurrentData$idSubstance == substance, c("worker", "dfrSpecWorker", "dt50FoliarWorker", "dt50AirWorker", "dt50SoilWorker",
                          "res", "dfrSpecRes", "dt50Res",
                          "bys", "dfrSpecBys", "dt50Bys")]
              
              if (!myCurrentData[myCurrentData$idCrop == crop & myCurrentData$idSubstance == substance, "defaultDermal"]) {
                myData[myData$idCrop == crop & myData$idSubstance == substance, c("defaultDermal", "apDermal")] <- myCurrentData[myCurrentData$idCrop == crop & 
                        myCurrentData$idSubstance == substance, c("defaultDermal", "apDermal")]
              }
            }
          }
        }
        
        
        refresh <<- input$entry_refresh 
        
      } else {
        
        # Update table with user input 
        myData <- hot_to_r(input$entry_absorptionInput)
        req(results$substanceData)
        
        # If entered concentration -> update absorption
        if (any(myData$defaultDermal)) {
          for (i in which(myData$defaultDermal)) {
            
            subData <- subset(results$substanceData, id == myData$idSubstance[i],
                select = c("concentration", "mlDermal"))
            # sort by concentration
            subData <- subData[order(subData$concentration, decreasing = TRUE), ]
            newIndex <- which(subData$concentration <= myData$dilutionConcentration[i])[1]
            if (is.na(newIndex))
              newValue <- subData$concentration[nrow(subData)]/myData$dilutionConcentration[i] * subData$mlDermal[nrow(subData)] else 
              newValue <- subData$mlDermal[newIndex]
            
            
            if (input$entry_formulation == 'G') {
              myData$apDermal[i] <- suppressWarnings(max(subData$mlDermal))
            } else {
              # cut-off value in case of solubles is 70
              myData$apDermal[i] <- min(c(70, as.numeric(newValue)))  
            }                    
            
            
          }
          
        }
        
      } 
      
      
      # Loaded data from file                
      if (newFile) {
        
        myData <- read.csv(file = results$loadedFiles$absorption, stringsAsFactors = FALSE)
        newFile <<- FALSE
        
        myData$dfrSpecWorker <- as.numeric(myData$dfrSpecWorker)
        myData$dfrSpecRes <- as.numeric(myData$dfrSpecRes)
        myData$dfrSpecBys <- as.numeric(myData$dfrSpecBys)
        
      } 
      
      # Reorder columns
      newOrder <- c("use", "substance", "crop", 
          "productConcentration", "dilutionConcentration", "defaultDermal", 
          "apDermal", "dfr0", "dt50", "worker", "dfrSpecWorker", "dt50FoliarWorker", "dt50AirWorker", "dt50SoilWorker", 
          "res", "dfrSpecRes", "dt50Res",
          "bys", "dfrSpecBys", "dt50Bys", "idSubstance", "idCrop")
      myData[, newOrder[newOrder %in% colnames(myData)]]
      
    })




# Display table for intended use
output$entry_absorptionInput <- renderRHandsontable({
      
      validate(need(!all(is.na(results$entry_absorptionData()$idSubstance)), 
              "Please add Active Substance(s) and Crop(s)"))
      
      
      # Labels  
      toReplace <- colnames(results$entry_absorptionData())
      toReplace <- toReplace[!toReplace %in% c("idSubstance", "idCrop")]
      toReplace[toReplace == "dt50"] <- "dt50_default"
      newCols <- c(fullLabels[toReplace], "idSubstance", "idCrop")
      names(newCols) <- NULL
      
      if (nrow(results$entry_absorptionData())*120 <= 540) {
        myTable <- rhandsontable(results$entry_absorptionData(),
                selectCallback = TRUE, 
                readOnly = TRUE,
                colHeaders = newCols,
                rowHeaders = FALSE,
                stretchH = "all") %>%
            hot_rows(rowHeights = 120) %>%
            hot_cols(colWidths = 130) %>%
            hot_cols(fixedColumnsLeft = 3) %>%
            hot_col(col = c(6, 10, 15, 18), readOnly = FALSE) %>%
            # Hide column
            # https://github.com/jrowen/rhandsontable/issues/249
            hot_col(col = "idSubstance", colWidths = 0.05) %>%
            hot_col(col = "idCrop", colWidths = 0.05) %>%
            hot_col(col = "DFR refined worker [\U00B5g/cm\u00B2 foliage per kg a.s./ha]", format = "0.00") %>%
            hot_col(col = "DFR refined resident [\U00B5g/cm\u00B2 foliage per kg a.s./ha]", format = "0.00") %>%
            hot_col(col = "DFR refined bystander [\U00B5g/cm\u00B2 foliage per kg a.s./ha]", format = "0.00")  
        
      } else {
        
        myTable <- rhandsontable(results$entry_absorptionData(),
                height = 540,
                selectCallback = TRUE, 
                readOnly = TRUE,
                colHeaders = newCols,
                rowHeaders = FALSE,
                stretchH = "all") %>%
            hot_rows(rowHeights = 120) %>%
            hot_cols(colWidths = 130) %>%
            hot_cols(fixedColumnsLeft = 3) %>%
            hot_col(col = c(6, 10, 15, 18), readOnly = FALSE) %>%
            # Hide columns
            # https://github.com/jrowen/rhandsontable/issues/249
            hot_col(col = "idSubstance", colWidths = 0.05) %>%
            hot_col(col = "idCrop", colWidths = 0.05)  %>%
            hot_col(col = "DFR refined worker [\U00B5g/cm\u00B2 foliage per kg a.s./ha]", format = "0.00") %>%
            hot_col(col = "DFR refined resident [\U00B5g/cm\u00B2 foliage per kg a.s./ha]", format = "0.00") %>%
            hot_col(col = "DFR refined bystander [\U00B5g/cm\u00B2 foliage per kg a.s./ha]", format = "0.00")   
      }
      
      # Editable absorption if no experimental data
      if (input$entry_formulation != "G") {
        editable <- which(!results$entry_absorptionData()$defaultDermal) 
        for (iRow in editable)
          myTable <- myTable %>%
              hot_cell(row = iRow, col = 7, readOnly = FALSE)
      }
      
      editable <- which(results$entry_absorptionData()$worker) 
      for (iRow in editable)
        myTable <- myTable %>%
            hot_cell(row = iRow, col = 11, readOnly = FALSE)%>%
            hot_cell(row = iRow, col = 12, readOnly = FALSE)%>%
            hot_cell(row = iRow, col = 13, readOnly = FALSE)%>%
            hot_cell(row = iRow, col = 14, readOnly = FALSE)
      
      editable <- which(results$entry_absorptionData()$res) 
      for (iRow in editable)
        myTable <- myTable %>%
            hot_cell(row = iRow, col = 16, readOnly = FALSE)%>%
            hot_cell(row = iRow, col = 17, readOnly = FALSE)
      
      editable <- which(results$entry_absorptionData()$bys) 
      for (iRow in editable)
        myTable <- myTable %>%
            hot_cell(row = iRow, col = 19, readOnly = FALSE)%>%
            hot_cell(row = iRow, col = 20, readOnly = FALSE)
      
      
      
      myTable
      
    })



# Warning if dermal absorption missing
output$entry_absorptionWarning <- renderUI({
      
      missingVariables <- colnames(results$entry_absorptionData())[
          apply(results$entry_absorptionData(), 2, function(x) any(is.na(x) | x == ""))]
      
      # concentration does not make sense for granules    
      if(input$entry_formulation == "G") {
        missingVariables <- missingVariables[missingVariables != "productConcentration"]
        missingVariables <- missingVariables[missingVariables != "dilutionConcentration"]
      }
      
      # need to refresh when add
      needRefresh <- !all(results$substanceData$id %in% results$entry_absorptionData()$idSubstance) |
          !all(results$cropData$id %in% results$entry_absorptionData()$idCrop)
      
      # need to refresh when delete
      needRefresh2 <- !all(results$entry_absorptionData()$idSubstance %in% results$substanceData$id) |
          !all(results$entry_absorptionData()$idCrop %in% results$cropData$id)
      
      
      
      warningStyle(
          
          if (length(missingVariables) > 0)
            tags$p(
                "Values are missing for",
                tags$ul(
                    lapply(missingVariables, function(iName)
                          tags$li(fullLabels[iName]))
                )
            ),
          if (needRefresh | needRefresh2)
            tags$p("Please refresh the Intended Use table to match with updated Active Substances and Crops.")
      
      )
      
    })
