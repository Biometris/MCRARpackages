# Project: opex_git
#
# server file - Results for operator
# 
# Author: mvarewyck
###############################################################################


## -------- ##
## Scenario ##
## -------- ##

## Select crop
output$op_crop <- renderUI({
      
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      
      
      choices <- unique(results$cropData$id)
      names(choices) <- paste0(results$cropData$use[match(choices, results$cropData$id)], ": ", 
          results$cropData$crop[match(choices, results$cropData$id)])
      
      radioButtons(inputId = "op_crop", label = "Crop", choices = choices,
          inline = TRUE)
      
    })

## Select substance
#output$op_substance <- renderUI({
#      
#      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
#          need(results$cropData, "Please define crop(s) in the Data Entry page"))
#      
#      
#      choices <- unique(results$substanceData$id)
#      names(choices) <- results$substanceData$substance[match(choices, results$substanceData$id)]
#      
#      radioButtons(inputId = "op_substance", label = "Substance", choices = choices,
#          inline = TRUE)
#      
#    })



# All possible scenarios defined by crop
results$op_scenarioData <- reactive({
      
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "operator",
          crops = allData$equipment,
          dataDefault = allData$default
      )
      
    })





# Summary of entered values for calculations
output$op_entry <- DT::renderDT({
      
      req(input$op_crop)
      
      
      displayScenario(scenarios = results$op_scenarioData()[[input$op_crop]], 
          person = "operator")
      
    })





# Warning if vehicle-mounted was removed
output$op_warning <- renderUI({
      
      req(input$op_crop)
      
      if (any(grepl("TM", results$cropData[results$cropData$id == input$op_crop, "applicationEquipment"])))
        warningStyle("For indoor scenario, no model results are available for 'Vehicle-mounted', these scenarios are automatically excluded")
      
    })



## --------------- ##
## Single scenario ##
## --------------- ##


output$op_risksSingle <- DT::renderDT({
      
      validate(need(input$op_entry_rows_selected,
              "Please select a row from the table above"))
      
      tableAllRisks(
          risks = results$op_risksAll(),
          scenarioNo = input$op_entry_rows_selected,
          scenario = results$op_scenarioData()[[input$op_crop]])
      
    })



## ------- ##
## All PPE ##
## ------- ##


# Legend for color coding
output$op_legend <- renderUI({
      
      tagList(
          tags$b("Legend"),
          tags$p(drawBullet(color = myColors$green), "Safe use with workwear"),
          tags$p(drawBullet(color = myColors$yellow), "Safe use with PPE"),
          tags$p(drawBullet(color = myColors$red), "No safe use"),
          tags$p(drawBullet(color = myColors$gray), "No data to calculate the exposure for this scenario"),
      )
      
    })



## general UI layout
observe({
      req(input$op_crop)
      output$op_tabs <- renderUI({
            tabsetPanel(
                tabPanel("Per Substance",
                    
                    
                    DT::DTOutput("op_risksAll"),
                    
                    tags$div(style = "margin-top:20px")
                ),
                tabPanel("Combined exposure", 
                    
                    DT::DTOutput("op_risksAllCombExp"),
                    
                    tags$div(style = "margin-top:20px")
                
                )
            )
            
          })
      
    })


# Calculate risk for all ppe
results$op_risksAll <- reactive({
      
      req(input$op_crop)
      validate(need(nrow(results$op_scenarioData()[[input$op_crop]]) > 0,
              "No results available"))
      
      toReturn <- calculateRisks(
          scenarios = results$op_scenarioData()[[input$op_crop]]
      )
      
      validate(need(nrow(toReturn) > 0, "No results available"))
      toReturn
      
    })

##---------------##
## per substance ##
##---------------##

output$op_warningExposure <- renderUI({
      req(input$op_crop)
   
      riskList <- results$op_risksAll()
      percentile <- input$op_percentile
      
      noScenarios <- nrow(results$op_scenarioData()[[input$op_crop]])
      scenarios <- results$op_scenarioData()[[input$op_crop]] 
      warning <- NA
      
      req(all(!is.na(results$op_scenarioData()[[input$op_crop]])))
      
      for (i in 1:noScenarios) {
        
        totalExp <- paste0(i, "_total", percentile)
        
        if (riskList[7, totalExp] >= riskList[3, totalExp]) {
            warning <- "Based on theoretical extrapolation from high application rates, 
												the exposure for protected hands is higher than for unprotected hands 
												for very low application rates (no measured values are available 
												for very low application rates). In this case the highest level of protection 
												(including protecting gloves) should be worn if the use of this combination of PPE is safe."
       
        }
      }

  
        if(!is.na(warning))
            warningStyle(paste("Warning:", warning))
            
      
    })


# Table with calculated risks
output$op_risksAll <- DT::renderDT({
      
      req(input$op_crop)
      req(input$op_percentile)
      
      # Check whether results are available for this percentile
      aoelName <- switch(input$op_percentile,
          "75" = "aoel",
          "95" = "aaoel"
      )
      noResults <- all(is.na(results$op_scenarioData()[[input$op_crop]][, aoelName]))
      validate(need(!noResults, "No results available for this percentile"))
      
      # Display table
      tableAllPpe(
          risks = results$op_risksAll(),
          percentile = input$op_percentile,
      )
      
    })

##-------------------##
## Combined exposure ##
##-------------------##




# Table with calculated risks
output$op_risksAllCombExp <- DT::renderDT({
      
      req(input$op_crop)
      
      # Check whether results are available for this percentile
      aoelName <- switch(input$op_percentile,
          "75" = "aoel",
          "95" = "aaoel"
      )
      noResults <- all(is.na(results$op_scenarioData()[[input$op_crop]][, aoelName]))
      validate(need(!noResults, "No results available for this percentile"))
      
      risksCombined <- combinedExposure(results$op_risksAll(), results$op_scenarioData()[[input$op_crop]])
      
      
      
      scenarioNames <- list()
      scenarioNames[[1]] <- ""
      scenarioNames[[2]] <- attr(results$op_risksAll(), "scenarioNames")$row2
      
      # Display table
      tableAllPpeCombined(
          risks = risksCombined,
          percentile = input$op_percentile,
          scenarioNames = scenarioNames
      )
      
    })

