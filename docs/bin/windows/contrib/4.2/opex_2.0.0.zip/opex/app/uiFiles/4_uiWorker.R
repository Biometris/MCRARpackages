# Worker UI
# 
# Author: mvarewyck
###############################################################################


tabPanel(title = "Worker", {
      
      fluidPage(
          
          h2("Description"),
          
          p(tags$b("Workers"), "are persons  who,  as  part  of  their  employment,  
                  enter  an  area  that  has  been  treated previously with a PPP or 
                  who handle a crop that has been treated with a PPP. "),
          wellPanel(
              uiOutput("worker_crop"),
              #uiOutput("worker_substance"),
              DT::DTOutput("worker_entry"),
          ),	
          
          uiOutput(outputId = "worker_uiOutput"),
                    
#          conditionalPanel("input.entry_formulation == 'G'", 
#             
#          ),
#          conditionalPanel("input.entry_formulation != 'G'",
#              h2("Output at d0"),
#              
#              h3("Single Scenario"),
#              helpText(textOutput(outputId = "single_scenario_info")),
#              
#              tags$div(style = "margin-bottom:50px", 
#                  tableOutput("worker_risksSingle")
#              ),
#              
#              h3("All Substances"),
#              
#              tabsetPanel(id = "worker_tabs",
#                  
#                  tabPanel("Per Substance",
#                      uiOutput(outputId = "worker_risks"),
#                      
#                  ),
#                  tabPanel("Combined exposure",
#                      
#                      tableOutput(outputId = "worker_sumTables")
#            
#                  )
#              
#              )
#          )
      
      
      )
      
    })
