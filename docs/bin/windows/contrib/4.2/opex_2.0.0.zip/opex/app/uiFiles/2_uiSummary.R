# Summary of all calculated risks
# 
# Author: mvarewyck
###############################################################################


tabPanel(title = "Summary", {
      
      fluidPage(
          
          tags$h2("Safe Use per Crop"),
          tags$p("The worst case for all substances and all application equipments 
                  is selected with minimum necessary protection level to reach an 
                  exposure level below the (A)AOEL in the listed scenarios"),
          
          
          
          wellPanel(
              fluidRow(
                  column(1, actionButton("generateReport", label = "Generate Report")),
                  column(1, shinyjs::disabled(downloadButton("summary_report", label = "Download Report")))
              ),
              singleton(tags$head(HTML(
                          '
                              <script type="text/javascript">
                              $(document).ready(function() {
                              // disable download at startup. data_file is the id of the downloadButton
                              $("#summary_report").attr("disabled", "true").attr("onclick", "return false;");
                              
                              Shiny.addCustomMessageHandler("download_ready", function(message) {
                              $("#summary_report").removeAttr("disabled").removeAttr("onclick").html(
                              "<i class=\\"fa fa-download\\"></i>Download Report");
                              });
                              })
                              </script>
                              '
                      ))),
              tags$p(""),
              uiOutput("summary_crop"),
              uiOutput("summary_season")
          ),
          fluidRow(
              column(1, 
                  tags$b("Navigate to:")
              )
          ),
          fluidRow(
              column(width = 1,
                  tags$ul(
                      tags$li(tags$a("Operator", href = "#operator")),
                      tags$li(tags$a("Worker", href = "#worker")),
                      tags$li(tags$a("Resident", href = "#resident")),
                      tags$li(tags$a("Bystander", href = "#bystander"))
                  )
              )
          ),
          tags$h3(id = "operator", "Operator"),
          uiOutput("summary_bestOperator"),
          uiOutput("summary_bestOperatorCombined"),
          uiOutput("summary_messageOperator"),
          
          
          
          tags$h3(id = "worker", "Worker"),
          uiOutput(outputId = "summary_uiOutputWorker"),
#          conditionalPanel(condition = "input.entry_formulation != 'G'",
#              uiOutput(outputId = "summary_risksWorker"),
#              uiOutput(outputId = "summary_sumTablesWorker")
#          ),
#          conditionalPanel(condition = "input.entry_formulation == 'G'",
#              warningStyle("No results available for Granules, fine granules!")
#          ),
          
          tags$h3(id = "resident", "Resident"),
          uiOutput(outputId = "summary_risksRes"),
          uiOutput(outputId = "summary_sumTablesRes"),
          
          tags$h3(id = "bystander", "Bystander"),
          uiOutput(outputId = "summary_risksBys"),
          uiOutput(outputId = "summary_sumTablesBys"),
      )
      
    })
