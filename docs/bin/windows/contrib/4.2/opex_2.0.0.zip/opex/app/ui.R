function(request) {
  
  shinyUI(
      
      fluidPage(theme = "shiny.css",
          
#					useShinyjs(debug = TRUE),
#					useShinyFeedback(),
          
          tags$head(includeScript("www/activateTableLink.js")),
          tags$head(includeScript("www/sequential_nav.js")),
          
          uiOutput("debug"),
          
          efsaHeaderUI(id = "header",
              title = "Exposure assessment for operator, worker, bystander and resident",
              titleImage = "efsaStyle/images/EFSAlogo.png",
              version = packageVersion("opex"),
              windowTitle = "OPEX"
          ),
          
#                    fluidRow(
#                            column(8,
#                                    
#                                    titlePanel(title = div(
#                                                    img(src = "EFSA_logo.JPG", height = "60px", hspace = "50px"),
#                                                    "Exposure assessment for operator, worker, bystander and resident"), 
#                                            windowTitle = "OPEX")
#                            ), 
#                            column(4, 
#                                    tags$div(style = "margin-right:15px; margin-top:15px", align = "right",
          ##                                            actionLink(inputId = "about", label = "Manual"), 
          ##                                            "-",
#                                            a(href="https://projects.openanalytics.eu/projects/opex2-issues/issues/new", 
#                                                    target="_blank", "Report new issue")
#                                    ),
#                                    tags$div(style = "color:gray; margin-right:15px", align = "right",
#                                            textOutput("version")
#                                    )
#                            )
#                    ),
          
          
          
          uiOutput("tabPanels")
      
      
      )
  )
  
}

