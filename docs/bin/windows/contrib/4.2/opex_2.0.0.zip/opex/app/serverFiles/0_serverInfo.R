# Info on how values are calculated
# 
# Author: mvarewyck
###############################################################################



# Go to Data Entry
observeEvent(input$info_dataEntry,
    updateTabsetPanel(session = session, inputId = "tabs", selected = "Product")
)

observeEvent(input$info_dataEntry2,
    updateTabsetPanel(session = session, inputId = "tabs", selected = "Product")
)

# Go to Analysis
observeEvent(input$info_summary,
    if(results$entry_valid())
      updateTabsetPanel(session = session, inputId = "tabs", selected = "Summary")
)

# Go to Report
observeEvent(input$info_operator,
    if(results$entry_valid())
      updateTabsetPanel(session = session, inputId = "tabs", selected = "Operator")
)

observeEvent(input$info_worker,
    if(results$entry_valid())
      updateTabsetPanel(session = session, inputId = "tabs", selected = "Worker")
)

observeEvent(input$info_resident,
    if(results$entry_valid())
      updateTabsetPanel(session = session, inputId = "tabs", selected = "Resident")
)

observeEvent(input$info_bystander,
    if(results$entry_valid())
      updateTabsetPanel(session = session, inputId = "tabs", selected = "Bystander")
)




## Example data
#output$info_exampleData <- downloadHandler(
#        filename = "opex.zip",
#        content = function(file) {
#            
#            # Copy files
#            allFiles <- lapply(c(TRUE, FALSE), function(x)
#                        list.files(path = system.file("extdata", package = "opex"),
#                                pattern = "example_", full.names = x))
#            newFiles <- gsub("example_", "", allFiles[[2]])
#            file.copy(allFiles[[1]], file.path(tempdir(), newFiles))
#            
#            # Create zip
#            oldDir <- getwd()
#            setwd(tempdir())
#            on.exit(setwd(oldDir))
#            
#            
#            zip(zipfile = file, files = newFiles)
#            
#        },
#        contentType = "application/zip")


# Example data - go to Product page
observeEvent(input$info_example, {
      
      updateTabsetPanel(session = session, inputId = "tabs", selected = "Product")
      
    })


# Download R package
output$info_package <- downloadHandler(
    filename = function() zipFile,
    content = function(file) {
      
      file.copy(from = file.path(system.file("app/www", package = "opex"), zipFile), to = file)
      
    },
    contentType = "application/zip")

# Show table
output$info_table <- renderUI({
      
      req(input$summary_show)
      
      showData <- allData[[input$summary_show]]
      
      if (input$summary_show  == "protectionFactors")
        lapply(seq_along(showData), function(i) 
              list(
                  h3(names(showData)[i]),
                  renderTable(showData[[i]], rownames = TRUE)
              )
        ) else if (input$summary_show %in% c("aoem", "indoor"))
        lapply(seq_along(showData), function(i)
              list(
                  h3(names(showData)[i]),
                  lapply(seq_along(showData[[i]]), function(j) 
                        list(
                            h4(names(showData[[i]])[j]),
                            renderTable(showData[[i]][[j]], rownames = TRUE)
                        )
                  )
              )
        ) else if (input$summary_show == "equipment") 
        list(renderTable(showData[showData$scenario == "outdoor", ], rownames = TRUE)) else
        list(renderTable(showData, rownames = TRUE))
      
    })



output$sessionInfo <- renderPrint({
      sessionInfo()
    })

output$info_icons <- DT::renderDT({
      
      icons <- getImages(protection = c(
              "No", "None",
              # body
              "Protected Body", "Rain Suit Body", "Coverall Body",
              # hands
              "Protected Hands",
              # head
              "Visor", "Hood", "Hood and faceshield", "Faceshield",
              # inhalation
              "FP1, P1 and similar", "FP2, P2 and similar",
              "Hood and FP1, P1 and similar", "Hood and FP2, P2 and similar",
              "Closed cabin"))
      
      icons$image <- tapply(icons$image, icons$index, function(iFiles)
            paste(sprintf('<img src="data:image/png;base64,%s" height="52"></img>', iFiles), collapse = " ")
      )
      
      icons$name <- c(
          "No safe use", "No Workwear",
          # body
          "Workwear", "Rain suit & trousers", "Certified protective coverall",
          # hands
          "Gloves",
          # head
          "Visor", "Hood", "Hood & faceshield", "Faceshield",
          # inhalation
          "FP1, P1 and similar", "FP2, P2 and similar",
          "Hood and FP1, P1 and similar", "Hood and FP2, P2 and similar",
          "Closed cabin")
      
      icons$info <- c(
          "", "",
          # body
          "", "If this PPE is selected, rain suit is always considered for high crops and rain trousers are always considered for low crops.",
          "",
          # Hands
          "", 
          # head
          "", "", "", "",
          # inhalation
          "", "", "", "", "")
      
      icons$index <- NULL
      icons$epsilon <- NULL
      
      DT::datatable(icons,
          selection = 'none',
          rownames = FALSE,
          colnames = c("Icon", "PPE", "Additional information"),
          escape = FALSE, 
          options = list(dom = 't',
              lengthMenu = list(c(-1), list('All')))
      )
      
    })