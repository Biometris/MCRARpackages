# Summary of Results
# 
# Author: mvarewyck
###############################################################################


output$summary_crop <- renderUI({
      
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      
      choices <- unique(results$cropData$id)
      names(choices) <- paste0(results$cropData$use[match(choices, results$cropData$id)], ": ", 
          results$cropData$crop[match(choices, results$cropData$id)])
      
      radioButtons(inputId = "summary_crop", label = "Crop", choices = choices,
          inline = TRUE)
      
    })


# Select season
output$summary_season <- renderUI({
      req(input$summary_crop)
      if(is.null(results$summary_scenariosRes()[[input$summary_crop]]$season))
        req(NULL)
      else {
        
        choices <- unique(results$summary_scenariosRes()[[input$summary_crop]]$season)
        names(choices) <- 
            
            radioButtons(inputId = "summary_season", label = "Season", choices = choices,
                inline = TRUE)
      }
    })
## -------- ##
## OPERATOR ##
## -------- ##


# Best PPE 
# for ml and app 
# for 75th and 95th percentile


results$summary_scenarios <- reactive({
      
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "operator",
          crops = allData$equipment,
          dataDefault = allData$default)
      
    })

results$summary_complete <- reactive({
      
      # Select scenarios with results
      scenarios <- results$summary_scenarios()[
          sapply(results$summary_scenarios(), nrow) > 0]
      
      
      riskList <- lapply(scenarios, function(iScenario) {
            calculateRisks(
                scenarios = iScenario
            )
          }
      )
      
      list(
          riskList = riskList,
          scenarios = scenarios
      )  
      
    })


# Operator - summary tables
output$summary_bestOperator <- renderUI({
      
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      
      req(input$summary_crop)
#            tableBestPpe(
#                    riskList = results$summary_complete()$riskList,
#                    scenarios = results$summary_complete()$scenarios
#            )
      
      
      
      
      acute = !all(is.na(results$summary_scenarios()[[input$summary_crop]][, "aaoel"]))
      longTerm = !all(is.na(results$summary_scenarios()[[input$summary_crop]][, "aoel"]))
      
      if (!acute & longTerm)
        percentiles <- "75"
      else if (acute & !longTerm)
        percentiles <- 95
      else
        percentiles <- c("75", "95")
      
      lapply(percentiles, function(percentile) {
            if (results$summary_complete()$scenarios[[input$summary_crop]]$formulation[1] == "G") {
              # Select cropId and percentile
              tmpRisks <- results$summary_complete()$riskList[[input$summary_crop]]
              
              wideTable <- tmpRisks[, grep(paste0("Body|Hands|Inhalation|total", percentile), colnames(tmpRisks))]
              
              
              
              # (1) Row with safe PPE
              idSafe <- sort(apply(wideTable[, -(1:6), drop = FALSE], 2, function(x) 
                        if (all(is.na(x))) NA else suppressWarnings(min(which(x < 100)))))
              ## if no safe use, report last row
              idSafe[idSafe == Inf] <- nrow(wideTable)
              
              # if last row is NA
              for (i in 1:length(idSafe)) {
                if (idSafe[i] == nrow(wideTable)) {
                  table <- wideTable[, c(-(1:6)), drop = FALSE]
                  idSafe[i] <- max(which(!is.na(table[ ,i]))) 
                }
              }
              
              idSafe <- sort(idSafe)
              
              fullData <- wideTable[unique(c(1:2, idSafe)), ]
              scenarioNames <- list()
              scenarioNames[[1]] <- attr(results$summary_complete()$riskList[[input$summary_crop]], "scenarioNames")$row1
              scenarioNames[[2]] <- attr(results$summary_complete()$riskList[[input$summary_crop]], "scenarioNames")$row2
              # 2 digits
              fullData[, grep("total", colnames(fullData))] <- sapply(fullData[, grep("total", colnames(fullData))], function(x) {
                    roundFinal(x)
                  })
              fullData[fullData == 0] <- NA
              
              tagList(
                  h4(paste(
                          results$summary_complete()$scenarios[[input$summary_crop]]$crop[1],
                          "-",
                          if(percentile == '75') 
                                "Short term exposure (% AOEL)" else 
                                "Acute exposure (% AAOEL)")
                  ),
                  
                  renderDT({
                        tableAllPpeSummary(
                            risks = fullData,
                            percentile = percentile,
                            scenarioNames = scenarioNames
                        )
                      })
              
              )
              
            } else {
              # Select cropId and percentile
              tmpRisks <- results$summary_complete()$riskList[[input$summary_crop]]
              
              wideTable <- tmpRisks[, grep(paste0("Body|Hands|Head|total", percentile), colnames(tmpRisks))]
              
              
              # (1) Row with safe PPE
              idSafe <- sort(apply(wideTable[, -(1:6), drop = FALSE], 2, function(x) 
                        if (all(is.na(x))) NA else suppressWarnings(min(which(x < 100)))))
              ## if no safe use, report last row
              idSafe[idSafe == Inf] <- nrow(wideTable)
              
              # if last row is na
              for (i in 1:length(idSafe)) {
                for (i in 1:length(idSafe)) {
                  if (idSafe[i] == nrow(wideTable)) {
                    table <- wideTable[, c(-(1:6)), drop = FALSE]
                    idSafe[i] <- max(which(!is.na(table[ ,i]))) 
                  }
                }
              }
              idSafe <- sort(idSafe)
              
              
              
              fullData <- wideTable[unique(c(1:2, idSafe)), ]
              scenarioNames <- list()
              scenarioNames[[1]] <- attr(results$summary_complete()$riskList[[input$summary_crop]], "scenarioNames")$row1
              scenarioNames[[2]] <- attr(results$summary_complete()$riskList[[input$summary_crop]], "scenarioNames")$row2
              # 2 digits
              fullData[, grep("total", colnames(fullData))] <- sapply(fullData[, grep("total", colnames(fullData))], function(x) {
                    roundFinal(x)
                  })
              fullData[fullData == 0] <- NA
              
              tagList(
                  h4(paste(
                          results$summary_complete()$scenarios[[input$summary_crop]]$crop[1],
                          "-",
                          if(percentile == '75') 
                                "Short term exposure (% AOEL)" else 
                                "Acute exposure (% AAOEL)")
                  ),
                  
                  renderDT({
                        tableAllPpeSummary(
                            risks = fullData,
                            percentile = percentile,
                            scenarioNames = scenarioNames
                        )
                      })
              
              )
            }
            
          })
      
      
      
    })

output$summary_bestOperatorCombined <- renderUI({
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      req(input$summary_crop)
      
      acute = !all(is.na(results$summary_scenarios()[[input$summary_crop]][, "aaoel"]))
      longTerm = !all(is.na(results$summary_scenarios()[[input$summary_crop]][, "aoel"]))
      
      if (!acute & longTerm)
        percentiles <- "75"
      else if (acute & !longTerm)
        percentiles <- 95
      else
        percentiles <- c("75", "95")
      
      noSubstances <- length(unique(results$summary_complete()$scenarios[[input$summary_crop]]$substance))
      
      if (noSubstances > 1) {
        lapply(percentiles, function(percentile) {
              if (results$summary_complete()$scenarios[[input$summary_crop]]$formulation[1] == "G") {
                # Select cropId and percentile
                tmpRisks <- combinedExposure(results$summary_complete()$riskList[[input$summary_crop]], results$summary_complete()$scenarios[[input$summary_crop]])
                
                wideTable <- tmpRisks[, grep(paste0("Body|Hands|Inhalation|total", percentile), colnames(tmpRisks))]
                
                
                
                # (1) Row with safe PPE
                idSafe <- sort(apply(wideTable[, -(1:6), drop = FALSE], 2, function(x) 
                          if (all(is.na(x))) NA else suppressWarnings(min(which(x < 1)))))
                ## if no safe use, report last row
                idSafe[idSafe == Inf] <- nrow(wideTable)
                
                # if last row is NA
                for (i in 1:length(idSafe)) {
                  if (idSafe[i] == nrow(wideTable)) {
                    table <- wideTable[, c(-(1:6)), drop = FALSE]
                    idSafe[i] <- max(which(!is.na(table[ ,i]))) 
                  }
                }
                
                idSafe <- sort(idSafe)
                
                fullData <- wideTable[unique(c(1:2, idSafe)), ]
                scenarioNames <- list()
                scenarioNames[[1]] <- ""
                scenarioNames[[2]] <- attr(results$summary_complete()$riskList[[input$summary_crop]], "scenarioNames")$row2
                # 2 digits
                fullData[, grep("total", colnames(fullData))] <- sapply(fullData[, grep("total", colnames(fullData))], function(x) {
                      roundFinal(x)
                    })
                fullData[fullData == 0] <- NA
                
                tagList(
                    h4(paste(
                            results$summary_complete()$scenarios[[input$summary_crop]]$crop[1],
                            "-",
                            if(percentile == '75') 
                                  "Short term combined exposure (hazard index)" else 
                                  "Acute combined exposure (hazard index)")
                    ),
                    
                    renderDT({
                          tableAllPpeSummary(
                              risks = fullData,
                              percentile = percentile,
                              scenarioNames = scenarioNames
                          )
                        })
                
                
                )
                
              } else {
                # Select cropId and percentile
                tmpRisks <- combinedExposure(results$summary_complete()$riskList[[input$summary_crop]], results$summary_complete()$scenarios[[input$summary_crop]])
                
                wideTable <- tmpRisks[, grep(paste0("Body|Hands|Head|total", percentile), colnames(tmpRisks))]
                
                
                # (1) Row with safe PPE
                idSafe <- sort(apply(wideTable[, -(1:6), drop = FALSE], 2, function(x) 
                          if (all(is.na(x))) NA else suppressWarnings(min(which(x < 1)))))
                ## if no safe use, report last row
                idSafe[idSafe == Inf] <- nrow(wideTable)
                
                
                # if last row is NA
                if(length(idSafe) != 0) {
                  for (i in 1:length(idSafe)) {
                    if (idSafe[i] == nrow(wideTable)) {
                      table <- wideTable[, c(-(1:6)), drop = FALSE]
                      idSafe[i] <- max(which(!is.na(table[ ,i]))) 
                    }
                    
                  }
                }
                idSafe <- sort(idSafe)
                
                
                fullData <- wideTable[unique(c(1:2, idSafe)), ]
                scenarioNames <- list()
                scenarioNames[[1]] <- ""
                scenarioNames[[2]] <- attr(results$summary_complete()$riskList[[input$summary_crop]], "scenarioNames")$row2
                # 2 digits
                fullData[, grep("total", colnames(fullData))] <- sapply(fullData[, grep("total", colnames(fullData))], function(x) {
                      roundFinal(x)
                    })
                fullData[fullData == 0] <- NA
                
                tagList(
                    h4(paste(
                            results$summary_complete()$scenarios[[input$summary_crop]]$crop[1],
                            "-",
                            if(percentile == '75') 
                                  "Short term combined exposure (hazard index)" else 
                                  "Acute combined exposure (hazard index)")
                    ),
                    
                    renderDT({
                          tableAllPpeSummaryCombined(
                              risks = fullData,
                              percentile = percentile,
                              scenarioNames = scenarioNames
                          )
                        })
                
                
                )
                
              }
            })
      }
    })


# Crops without results
output$summary_messageOperator <- renderUI({
      
      # Crops without results
      excludedCrop <- names(results$summary_scenarios())[sapply(results$summary_scenarios(), nrow) == 0]
      
      # Substances without results
      excludedLong <- unlist(lapply(results$summary_scenarios(), function(iScenario) {
                if (any(is.na(iScenario[, "aoel"])))
                  unique(iScenario$substance[is.na(iScenario[, "aoel"])]) else
                  NULL}))
      excludedAcute <- unlist(lapply(results$summary_scenarios(), function(iScenario) { 
                if (any(is.na(iScenario[, "aaoel"])))
                  unique(iScenario$substance[is.na(iScenario[, "aaoel"])]) else
                  NULL}))
      
      tagList(
          warningStyle(
              if (length(excludedCrop) > 0)
                paste("No results are available for crop(s):", 
                    paste(results$cropData$crop[match(excludedCrop, results$cropData$id)], collapse = ", ")),
              if (!is.null(excludedLong))
                paste("Short term exposure could not be estimated for", paste(excludedLong, collapse = ", "))
          #if (!is.null(excludedAcute))
          #  paste("Acute exposure could not be estimated for", paste(excludedAcute, collapse = ", "))
          )
      )
      
    })


## ------ ##
## WORKER ##
## ------ ##


# All possible scenarios defined by crop
results$summary_scenariosWorker <- reactive({
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "worker",
          crops = allData$crops,
          dataDefault = allData$default
      )
      
    })

## Tables for all substances
results$summary_tablesWorker <- reactive({
      req(input$summary_crop)
      data <- results$worker_scenarioData()[[input$summary_crop]]
      
      workerOutputTables(data, allData)
    }) 

output$summary_uiOutputWorker <- renderUI({
      req(input$summary_crop)
      
      if (input$entry_formulation == "G" & results$worker_scenarioData()[[input$summary_crop]][1, "indoor"] == "Outdoor") {
        warningStyle("No results available for Granules, fine granules!")
      } else if (is.na(results$summary_scenariosWorker()[[input$summary_crop]]$activity[1]) |
          results$summary_scenariosWorker()[[input$summary_crop]]$activity[1] == "NA") {
        warningStyle("No results available, no re-entry activity available for worker!")
      } else {
        tagList(
            uiOutput(outputId = "summary_risksWorker"),
            uiOutput(outputId = "summary_sumTablesWorker")
        )
      }
      
    })

# Output tables for default dfr 
output$summary_risksWorker <- renderUI({
      
      req(input$summary_crop)
      
      lapply(seq_along(results$summary_tablesWorker()), function(noSubstance) {
            
            table <- roundFinal(results$summary_tablesWorker()[[noSubstance]][ , c('PPE', '% of AOEL at day 0', 'Safe re-entry interval (days)')])
            colors <- c()
            # add color column to table
            for(i in 1:nrow(table)) {
              
              value <- as.numeric(table[i, '% of AOEL at day 0'])
              
              if (is.na(value)) {
                colors <- c(colors, 0)
              } else if (i == 1 | i == 2) {
                if(value <= 100) {
                  colors <- c(colors, 1)
                } else{
                  colors <- c(colors, 3)
                }
              } else {
                if(value <= 100) {
                  colors <- c(colors, 2)
                } else{
                  colors <- c(colors, 3)
                }
              }
            }
            
            table <- cbind(table, colors)
            
            tagList(
                tags$h4(paste(results$summary_scenariosWorker()[[input$summary_crop]][noSubstance, c("substance")], collapse = " & ")),
                renderDT(DT::datatable(table,
                            selection = 'none',
                            escape = FALSE,
                            options = list(
                                dom = 't',
                                columnDefs = list(list(targets = 3, visible = FALSE)),
                                ordering = FALSE
                            )
                        )%>% formatStyle(
                            'colors',
                            target = 'row',
                            backgroundColor = styleEqual(c(0, 1, 2, 3), c('#cacfd2', '#abebc6', '#f4d03f', '#f5b7b1'))
                        )
                )
            )
            
            
          })
      
    })

# combined exposure
output$summary_sumTablesWorker <- renderUI({
      req(input$summary_crop)
      if (!is.na(results$summary_scenariosWorker()[[input$summary_crop]]$activity[1]) &
          results$summary_scenariosWorker()[[input$summary_crop]]$activity[1] != "NA") {
        table <- outputSumTables(results$summary_tablesWorker(), 
            scenarioData = results$summary_scenariosWorker()[[input$summary_crop]],
            allData = allData)
        
        # calculate the safe re-entry interval
        intervals <- combinedSafeReEntryInterval(params = results$summary_scenariosWorker()[[input$summary_crop]], 
            tables = results$summary_tablesWorker(), allData)
        
        table[, 7] <- intervals
        
        if (length(results$summary_tablesWorker()) > 1) {
          table <- table[ ,c('PPE', '% of AOEL at day 0', 'Safe re-entry interval (days)')]
          colors <- c()
          # add color column to table
          for(i in 1:nrow(table)) {
            
            value <- as.numeric(table[i, '% of AOEL at day 0'])
            
            if (is.na(value)) {
              colors <- c(colors, 0)
            } else if (i == 1 | i == 2) {
              if(value <= 1) {
                colors <- c(colors, 1)
              } else{
                colors <- c(colors, 3)
              }
            } else {
              if(value <= 1) {
                colors <- c(colors, 2)
              } else{
                colors <- c(colors, 3)
              }
            }
          }
          
          table <- cbind(table, colors)
          
          colnames(table)[2] <- "Hazard index at day 0" 
          
          tagList(
              tags$h4("Combined Exposure"),
              renderDT(DT::datatable(table,
                          selection = 'none',
                          escape = FALSE,
                          options = list(
                              dom = 't',
                              columnDefs = list(list(targets = 3, visible = FALSE)),
                              ordering = FALSE
                          )
                      )%>% formatStyle(
                          'colors',
                          target = 'row',
                          backgroundColor = styleEqual(c(0, 1, 2, 3), c('#cacfd2', '#abebc6', '#f4d03f', '#f5b7b1'))
                      )
              )
          )  
        }
      }
      
    })


## -------- ##
## RESIDENT ##
## -------- ##

## scenarios
results$summary_scenariosRes <- reactive({
      
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "resident",
          crops = allData$crops,
          dataDefault = allData$default
      )
      
    })

# input data per crop and per season
observe({
      req(input$summary_crop)
      req(input$summary_season)
      results$summary_perCropRes <- results$summary_scenariosRes()[[input$summary_crop]]
      results$summary_perSeasonRes <- results$summary_perCropRes[results$summary_perCropRes$season == input$summary_season, ]
    })

## Tables for all substances
results$summary_tablesRes <- reactive({
      req(results$summary_perSeasonRes)
      if(nrow(results$summary_perSeasonRes) > 0)
        as.list(residentOutputTables(results$summary_perSeasonRes))
    }) 

output$summary_risksRes <- renderUI({
      req(input$summary_crop)
      req(input$summary_season)
      if(nrow(results$summary_perSeasonRes) > 0) {
        if(results$summary_perSeasonRes[1, "formulation"] ==  "G" & results$summary_perSeasonRes[1, "indoor"] == "Indoor") {
          warningStyle("No results available for Granules, fine granules indoor!")
        } else {
          lapply(seq_along(results$summary_tablesRes()), function(noSubstance)	{	
                
                allRisks <- results$summary_tablesRes()[[noSubstance]]
                
                allRisks$Adults <- roundFinal(allRisks$Adults[3, , drop = FALSE])
                allRisks$Children <- roundFinal(allRisks$Children[3, , drop = FALSE])
                
                params <- results$summary_perSeasonRes[noSubstance, ]
                
                ## add colors
                if(params$bufferStrip == "2-3" & params$driftReduction == 0) {  
                  for(person in names(allRisks)) {
                    if(all(as.numeric(allRisks[[person]]) <= 100, na.rm = TRUE)) {
                      colors <- 1
                      allRisks[[person]] <- cbind(allRisks[[person]], colors)
                    } else {
                      colors <- 3
                      allRisks[[person]] <- cbind(allRisks[[person]], colors)
                    }
                  }
                } else {
                  for(person in names(allRisks)) {
                    if(all(as.numeric(allRisks[[person]]) <= 100, na.rm = TRUE)) {
                      colors <- 2
                      allRisks[[person]] <- cbind(allRisks[[person]], colors)
                    } else {
                      colors <- 3
                      allRisks[[person]] <- cbind(allRisks[[person]], colors)
                    }
                  }
                }
                
                tagList(
                    tags$h4(paste0(results$summary_perSeasonRes[noSubstance, "substance"], " (% AOEL)")),
                    fluidRow(
                        lapply(names(allRisks), function(x) {
                              column(6, 
                                  tags$h5(x),
                                  renderDT(DT::datatable(allRisks[[x]],
                                              selection = 'none',
                                              rownames = FALSE,
                                              escape = FALSE,
                                              options = list(
                                                  dom = 't',
                                                  columnDefs = list(list(targets = 
                                                              ifelse(params$crop == "Amenity grassland", 6, 5), visible = FALSE)),
                                                  ordering = FALSE
                                              )
                                          )%>% formatStyle(
                                              'colors',
                                              target = 'row',  
                                              backgroundColor = styleEqual(c(0, 1, 2, 3), c('#cacfd2', '#abebc6', '#f4d03f', '#f5b7b1'))
                                          ) 
                                  )
                              )
                            })
                    
                    )
                )
              })
        }
      }
    })

# combined exposure
output$summary_sumTablesRes <- renderUI({
      req(input$summary_crop)
      req(input$summary_season)
      if(nrow(results$summary_perSeasonRes) > 0) {
        if(results$summary_perSeasonRes[1, "formulation"] ==  "G" & results$summary_perSeasonRes[1, "indoor"] == "Indoor") {
          NULL
        } else {
          allRisks <- outputSumTables2(results$summary_tablesRes())
          
          allRisks$Adults <- roundFinal(allRisks$Adults[3, , drop = FALSE])
          allRisks$Children <- roundFinal(allRisks$Children[3, , drop = FALSE])
          
          params <- results$summary_perSeasonRes
          
          ## add colors
          if(all(params$bufferStrip == "2-3") & all(params$driftReduction == 0)) {  
            for(person in names(allRisks)) {
              if(all(as.numeric(allRisks[[person]]) <= 1, na.rm = TRUE)) {
                colors <- 1
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
                
              } else {
                colors <- 3
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              }
            }
          } else {
            for(person in names(allRisks)) {
              if(all(as.numeric(allRisks[[person]]) <= 1, na.rm = TRUE)) {
                colors <- 2
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              } else {
                colors <- 3
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              }
            }
          }
          
          if (length(results$summary_tablesRes()) > 1) {
            tagList(
                tags$h4("Combined exposure (hazard index)"),
                fluidRow(
                    lapply(names(allRisks), function(x)
                          column(6, 
                              tags$h5(x),
                              renderDT(DT::datatable(allRisks[[x]],
                                          selection = 'none',
                                          rownames = FALSE,
                                          escape = FALSE,
                                          options = list(
                                              dom = 't',
                                              columnDefs = list(list(targets = 5, visible = FALSE)),
                                              ordering = FALSE
                                          )
                                      )%>% formatStyle(
                                          'colors',
                                          target = 'row',
                                          backgroundColor = styleEqual(c(0, 1, 2, 3), c('#cacfd2', '#abebc6', '#f4d03f', '#f5b7b1'))
                                      ) 
                              )
                          
                          )
                    )
                )
            )
          }
        }
      }
    })


##-----------##
## BYSTANDER ##
##-----------##

## scenarios
results$summary_scenariosBys <- reactive({
      
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "bystander",
          crops = allData$crops,
          dataDefault = allData$default
      )
      
    })


# input data per crop and per season
observe({
      req(input$summary_crop)
      req(input$summary_season)
      results$summary_perCropBys <- results$summary_scenariosBys()[[input$summary_crop]]
      results$summary_perSeasonBys <- results$summary_perCropBys[results$summary_perCropBys$season == input$summary_season, ]
      
    })


## Tables for all substances
results$summary_tablesBys <- reactive({
      req(results$summary_perSeasonBys)
      if(nrow(results$summary_perSeasonBys) > 0)
        bystanderOutputTables(results$summary_perSeasonBys)
    }) 



output$summary_risksBys <- renderUI({
      req(input$summary_crop)
      req(input$summary_season)
      if(nrow(results$summary_perSeasonBys) > 0) {
        if(results$summary_perSeasonBys[1, "formulation"] == 'G' & results$summary_perSeasonBys[1, "indoor"] == "Indoor") {
          warningStyle("No results available for Granules, fine granules indoor!")
        } else {
          lapply(seq_along(results$summary_tablesBys()), function(noSubstance)	{	
                
                if (!is.na(results$summary_perSeasonBys[noSubstance,]$aaoel)) {
                  allRisks <- results$summary_tablesBys()[[noSubstance]]
                  
                  allRisks$Adults <- roundFinal(allRisks$Adults[3, , drop = FALSE])
                  allRisks$Children <- roundFinal(allRisks$Children[3, , drop = FALSE])
                  
                  params <- results$summary_perSeasonBys[noSubstance, ]
                  
                  ## add colors
                  if(params$bufferStrip == "2-3" & params$driftReduction == 0) {  
                    for(person in names(allRisks)) {
                      if(all(as.numeric(allRisks[[person]]) <= 100, na.rm = TRUE)) {
                        colors <- 1
                        allRisks[[person]] <- cbind(allRisks[[person]], colors)
                      } else {
                        colors <- 3
                        allRisks[[person]] <- cbind(allRisks[[person]], colors)
                      }
                    }
                  } else {
                    for(person in names(allRisks)) {
                      if(all(as.numeric(allRisks[[person]]) <= 100, na.rm = TRUE)) {
                        colors <- 2
                        allRisks[[person]] <- cbind(allRisks[[person]], colors)
                      } else {
                        colors <- 3
                        allRisks[[person]] <- cbind(allRisks[[person]], colors)
                      }
                    }
                  }
                  
                  
                  
                  tagList(
                      tags$h4(paste0(results$summary_perSeasonBys[noSubstance, "substance"]), " (% AAOEL)"),
                      fluidRow(
                          lapply(names(allRisks), function(x) {
                                column(6, 
                                    tags$h5(x),
                                    renderDT(DT::datatable(allRisks[[x]],
                                                selection = 'none',
                                                rownames = FALSE,
                                                escape = FALSE,
                                                options = list(
                                                    dom = 't',
                                                    columnDefs = list(list(targets = 4, visible = FALSE)),
                                                    ordering = FALSE
                                                )
                                            )%>% formatStyle(
                                                'colors',
                                                target = 'row',
                                                backgroundColor = styleEqual(c(0, 1, 2, 3), c('#cacfd2', '#abebc6', '#f4d03f', '#f5b7b1'))
                                            ) 
                                    )
                                )
                              })
                      
                      
                      )
                  )
                } else {
                  tagList(
                      tags$h4(results$summary_perSeasonBys[noSubstance, "substance"]),
                      tags$p("No results, AAOEL is not specified.")
                  )    
                }
              })
        }
      }
    })

# combined exposure
output$summary_sumTablesBys <- renderUI({
      req(input$summary_crop)
      req(input$summary_season)
      if(nrow(results$summary_perSeasonBys) > 0) {
        if(results$summary_perSeasonBys[1, "formulation"] == 'G' & results$summary_perSeasonBys[1, "indoor"] == "Indoor") {
          NULL
        } else {
          allRisks <- outputSumTables2(results$summary_tablesBys())
          
          allRisks$Adults <- roundFinal(allRisks$Adults[3, , drop = FALSE])
          allRisks$Children <- roundFinal(allRisks$Children[3, , drop = FALSE])
          
          params <- results$summary_perSeasonBys
          
          ## add colors
          if(all(params$bufferStrip == "2-3") & all(params$driftReduction == 0)) {  
            for(person in names(allRisks)) {
              if(all(as.numeric(allRisks[[person]]) <= 1, na.rm = TRUE)) {
                colors <- 1
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              } else {
                colors <- 3
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              }
            }
          } else {
            for(person in names(allRisks)) {
              if(all(as.numeric(allRisks[[person]]) <= 1, na.rm = TRUE)) {
                colors <- 2
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              } else {
                colors <- 3
                allRisks[[person]] <- cbind(allRisks[[person]], colors)
              }
            }
          }
          
          
          if (length(results$summary_tablesBys()) > 1) {
            tagList(
                tags$h4("Combined exposure (hazard index)"),
                fluidRow(
                    lapply(names(allRisks), function(x)
                          column(6, 
                              tags$h5(x),
                              renderDT(DT::datatable(allRisks[[x]],
                                          selection = 'none',
                                          rownames = FALSE,
                                          escape = FALSE,
                                          options = list(
                                              dom = 't',
                                              columnDefs = list(list(targets = 4, visible = FALSE)),
                                              ordering = FALSE
                                          )
                                      )%>% formatStyle(
                                          'colors',
                                          target = 'row', 
                                          backgroundColor = styleEqual(c(0, 1, 2, 3), c('#cacfd2', '#abebc6', '#f4d03f', '#f5b7b1'))
                                      ) 
                              )
                          )
                    )
                )
            )
          }
        }
      }
      
    })



## ------ ##
## REPORT ##
## ------ ##

## Operator

results$summary_reportTables <- reactive({
      
      lapply(results$summary_complete()$scenarios, function(iScenarios) {        
            
            lapply(1:nrow(iScenarios), function(iRow) {
                  
                  lapply(c('75', '95'), function(percentile) {
                        if (iScenarios[iRow, "formulation"] == "G"){
                          tmp <- operatorGranulesTables(
                              dataModel = if (iScenarios[iRow, "indoor"] == "Indoor")
                                    allData$indoor else
                                    allData$aoem, 
                              dataDefault = allData$default, 
                              dataProtection = allData$protectionFactors,
                              scenario = iScenarios[iRow, , drop = FALSE],
                              percentile = percentile,
                              protection = allData$ppeGranules,
                              allData = allData
                          )
                        } else {
                          tmp <- operatorTables(
                              dataModel = if (iScenarios[iRow, "indoor"] == "Indoor")
                                    allData$indoor else
                                    allData$aoem, 
                              dataDefault = allData$default, 
                              dataProtection = allData$protectionFactors,
                              scenario = iScenarios[iRow, , drop = FALSE],
                              percentile = percentile,
                              protection = allData$ppe,
                              allData = allData
                          )   
                        }
                        if (!is.null(tmp))
                          attr(tmp, "percentile") <- percentile
                        
                        tmp
                        
                      })
                  
                })
            
          })
      
    })






reportFile <- reactiveVal()


# generate report first
observeEvent(input$generateReport, {
      reportFile(NULL)
      
      tryCatch({
            outFile <- tempfile(fileext = ".docx")
            
            idNote <- showNotification("Creating report... Please wait", type = "message", duration = NULL)
            reportFile(rmarkdown::render(file.path("www", 'report_remake.Rmd'),
                    output_file = outFile))
            removeNotification(id = idNote)
            showNotification("Report is ready! The 'Download Report' button is now available.", type = "message", duration = NULL)
            session$sendCustomMessage(type = "download_ready", 
                message = list(id = "summary_report"))
            
          }, error = function(e) {
            removeNotification(id = idNote)
            showNotification(sprintf("Report could not be generated: %s", e$message),
                type = "error", duration = NULL)
            
          })
      
      
      
    })



# Download report
output$summary_report <- downloadHandler(
    filename = function() paste0(results$productData$name, "_",
          format(Sys.time(), "%Y%m%d"), ".docx"),
    content = function(file) {
      
      file.copy(reportFile(), file, overwrite = TRUE)
      
    })



