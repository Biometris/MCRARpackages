# Resident server
# 
# Author: mvarewyck
###############################################################################

## Select crop
output$resident_crop <- renderUI({
      
      validate(need(results$substanceData, "Please define substance(s) in the Data Entry page"),
          need(results$cropData, "Please define crop(s) in the Data Entry page"))
      
      
      choices <- unique(results$cropData$id)
      names(choices) <- paste0(results$cropData$use[match(choices, results$cropData$id)], ": ", 
          results$cropData$crop[match(choices, results$cropData$id)])
      radioButtons(inputId = "resident_crop", label = "Crop", choices = choices,
          inline = TRUE)
      
    })

## Select season
output$resident_season <- renderUI({
      req(input$resident_crop)
      
      
      choices <- unique(results$resident_scenarioData()[[input$resident_crop]]$season)
     
          
          radioButtons(inputId = "resident_season", label = "Season", choices = choices,
              inline = TRUE)
      
    })

## scenarios
results$resident_scenarioData <- reactive({
      
      getScenarios(
          name = input$entry_name,
          formulation = input$entry_formulation,
          wps = input$entry_wps,
          category = input$entry_category,
          substanceInput = results$substanceData, 
          cropInput = results$cropData,
          absorptionInput = results$entry_absorptionData(),
          person = "resident",
          crops = allData$crops,
          dataDefault = allData$default
      )
      
    })


# input data per crop and per season
observe({
      req(input$resident_crop)
      req(input$resident_season)
      results$resident_perCrop <- results$resident_scenarioData()[[input$resident_crop]]
      results$resident_perSeason <- results$resident_perCrop[results$resident_perCrop$season == input$resident_season, ]
    })


# Summary of entered values for calculations
output$resident_entry <- DT::renderDT({
      req(results$resident_perSeason)
      
      data <- results$resident_perSeason
      
      displayScenario(scenarios = data, 
          person = "resident")
      
      
    })

output$resident_generalUI <- renderUI({
      req(input$resident_crop)
      req(input$resident_season)
     
      if(nrow(results$resident_perSeason) > 0) {
        if(results$resident_perSeason[1, "formulation"] ==  "G" & results$resident_perSeason[1, "indoor"] == "Indoor") {
          warningStyle("No results available for Granules, fine granules indoor!")
        } else {
          tagList(
              h3(textOutput(outputId = "resident_singleScenario")),
              helpText(textOutput(outputId = "resident_single_scenario_info")),
              tags$div(style = "margin-bottom:50px", 
                  uiOutput("resident_risksSingle")
              ),
              uiOutput(outputId = "resident_tabs")
              )
        }
        
      }
      
    })




# single scenario
observe({
      req(input$resident_crop)
      
      output$resident_singleScenario <- renderText({"Single Scenario"})
      output$resident_single_scenario_info <- renderText({
            
            "Possibility to select a different scenario (row) from the table above."
          })
      output$resident_risksSingle <- renderUI({
            
            validate(need(input$resident_entry_rows_selected,
                    "Please select a row from the table above"))
            tables <- results$resident_tables()
            
            table <- tables[[input$resident_entry_rows_selected]]
            fluidRow(
                lapply(names(table), function(x)
                      column(6, 
                          tags$h4(x),
                          renderTable(roundFinal(table[[x]]), rownames = TRUE)
                      )
                )
            )
            
            
            
          })
      
      
    })
# general ui layout (2 tabpages)
observe({
      req(input$resident_crop)
      
      output$resident_tabs <- renderUI({
            tabsetPanel(
                tabPanel("Per Substance",
                    uiOutput(outputId = "resident_risks"),
                ),
                tabPanel("Combined exposure", 
                    helpText("The results are presented as exposure addition."),
                    uiOutput(outputId = "resident_sumTables"),
                )
            )
            
          })
      
    })

##-------------##
## default DFR ##
##-------------##


## Tables for all substances
results$resident_tables <- reactive({
      req(results$resident_perSeason)
      if(nrow(results$resident_perSeason) > 0)
        residentOutputTables(results$resident_perSeason)
    }) 



output$resident_risks <- renderUI({
      
      lapply(seq_along(results$resident_tables()), function(noSubstance)	{	
            
            textOutput("resident_substanceTitles")
            allRisks <- results$resident_tables()[[noSubstance]]
            
            
            tagList(
                tags$h3(results$resident_perSeason[noSubstance, "substance"]),
                fluidRow(
                    lapply(names(allRisks), function(x)
                          column(6, 
                              tags$h4(x),
                              renderTable(roundFinal(allRisks[[x]]), rownames = TRUE)
                          )
                    )
                
                )
            )
          })
    })





##-------------------##
## combined exposure ##
##-------------------##



# default dfr
output$resident_sumTables <- renderUI({
      
      tables <- outputSumTables2(results$resident_tables())
      
      rownames(tables$Children)[3] <- "Hazard index"
      rownames(tables$Adults)[3] <- "Hazard index"
      
      fluidRow(
          lapply(names(tables), function(x)
                column(6, 
                    tags$h4(x),
                    renderTable(tables[[x]], rownames = TRUE)
                )
          )
      )
      
    })

