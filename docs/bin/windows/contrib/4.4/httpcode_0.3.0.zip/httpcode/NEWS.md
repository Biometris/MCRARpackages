httpcode 0.3.0
==============

### NEW FEATURES

* Added support for additional non-official HTTP status codes, and filled in some missing details for some status codes (#6)

### MINOR IMPROVEMENTS

* added tests (#7)


httpcode 0.2.0
==============

### NEW FEATURES

* Many http codes now with verbose explanation of the status code, but 
returning the verbose explanation is optional (with default false) (#3)
* Added more status codes (#2)

### MINOR IMPROVEMENTS

* Fix cat and dog status code base URLs to https (#4)


httpcode 0.1.0
==============

### NEW FEATURES

* Released to CRAN.
